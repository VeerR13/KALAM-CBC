# Kalam Deliverable 2: Ambiguity Map

## Overview

This document details all 45 known ambiguous rules and definitional issues across the 20 government schemes. Each ambiguity is tracked with its source scheme(s), current engine handling, and recommended resolution path. Ambiguities are grouped by category for navigability.

---

## Category 1: Definitional Ambiguities

### AMB-01: Land Ownership - Leased/Sharecropped Land
**Schemes Affected:** PM-KISAN  
**Rule:** "Applicant must own cultivable land as per state land records"  
**Ambiguity:** Guidelines say 'landholding families' implying ownership. Lease and sharecrop arrangements unclear — must land be registered in applicant's name?  
**Current Handling:** Engine returns AMBIGUOUS if land_ownership in ['leases', 'sharecrop']. PM-KISAN strictly requires registered ownership.  
**Resolution:** Official clarification from Ministry of Agriculture needed. Recommend user consult Patwari or block office for local land record status. Sharecrop agreements may qualify in some states post-Supreme Court directive.

---

### AMB-02: Land Acquisition Timeline - Post-Feb 2019 Transfers
**Schemes Affected:** PM-KISAN  
**Rule:** "New land purchases after 01.02.2019 do not qualify transferee"  
**Ambiguity:** Cannot determine from profile whether land was acquired before/after Feb 2019. Exception for inheritance due to death — unclear if other family transfers qualify.  
**Current Handling:** Engine flags as AMBIGUOUS — cannot verify land acquisition date from profile.  
**Resolution:** User must provide land purchase deed or registration certificate showing acquisition date. Consult Patwari for inheritance eligibility clarification.

---

### AMB-03: NE States Land Identification
**Schemes Affected:** PM-KISAN  
**Rule:** Assam, Meghalaya, J&K have alternate identification mechanisms  
**Ambiguity:** Community-based land certificates and Vanshavali (lineage) charts accepted instead of formal title deeds in NE states.  
**Current Handling:** Engine flags AMBIGUOUS for state in [Assam, Meghalaya, Jammu & Kashmir, J&K]. Requires manual verification of local documentation standards.  
**Resolution:** Users in NE states should consult district agriculture office with alternate ID documents. Community forest user certificates may qualify as land proof.

---

### AMB-06: Census Towns vs Gram Panchayat Areas - Rural Status
**Schemes Affected:** MGNREGA  
**Rule:** "Applicant must reside in a rural area"  
**Ambiguity:** Census towns notified under panchayat jurisdiction — are they 'rural' for MGNREGA? Official boundary between rural and urban blurred.  
**Current Handling:** is_urban=true → FAIL; is_urban=false → PASS; peri-urban areas → AMBIGUOUS. User self-reports urban status.  
**Resolution:** Consult local Gram Panchayat. If area is notified as 'urban' under municipal corporation, likely ineligible. If notified under panchayat (even if census town), likely eligible.

---

### AMB-07: Migrant Workers - Panchayat Registration Origin
**Schemes Affected:** MGNREGA  
**Rule:** "Eligible in the panchayat where registered"  
**Ambiguity:** Which panchayat should migrant worker register in — origin or current destination? Guidelines suggest origin but ground practice varies.  
**Current Handling:** Engine cannot determine from profile; flags occupation=Migrant Worker as AMBIGUOUS.  
**Resolution:** Migrant workers should register in their current residence panchayat if they plan to stay ≥6 months. Consult Gram Panchayat in destination area. ONORC (One Nation One Ration Card) enables some portability.

---

### AMB-09: "Dilapidated House" Definition Varies by State
**Schemes Affected:** PMAY-G  
**Rule:** "Family must live in zero/one/two-room kutcha house or dilapidated pucca house"  
**Ambiguity:** 'Dilapidated' not quantitatively defined across all states. Local gram sabha verification determines eligibility.  
**Current Handling:** Cannot determine from profile; engine flags land_ownership=owns with missing housing details as AMBIGUOUS.  
**Resolution:** User must provide gram sabha certification of dilapidated status OR documented photographs of house condition. Consult Gram Panchayat for condition assessment.

---

### AMB-10: No National Property Registry for PMAY-U Verification
**Schemes Affected:** PMAY-U  
**Rule:** "Applicant must not own a pucca house in their name"  
**Ambiguity:** No national property registry for cross-verification of pucca house ownership across states. Self-declaration is only mechanism.  
**Current Handling:** land_ownership=owns marked AMBIGUOUS for PMAY-U (could be non-pucca). Engine cannot cross-verify nationally.  
**Resolution:** User should provide self-declaration affidavit that no pucca house is owned. In ambiguous cases, local municipality can verify property records at registration office. Notarized declaration recommended.

---

### AMB-11: Landless Household Allotment by Gram Panchayat
**Schemes Affected:** PMAY-G  
**Rule:** "Must have land to build on OR be allotted land by gram panchayat"  
**Ambiguity:** Beneficiary may need land allotted by gram panchayat. If they have no land at all, eligibility unclear.  
**Current Handling:** Engine returns AMBIGUOUS for land_ownership=none. User may qualify if GP allots land.  
**Resolution:** Landless households should approach Gram Panchayat and enquire about land allotment under PMAY-G or other schemes. PMAY-G can facilitate allotment as part of scheme benefit.

---

### AMB-15: Ujjwala Proof Requirements Vary by Pathway
**Schemes Affected:** Ujjwala  
**Rule:** "Poor household based on deprivation declaration. BPL ration card or low income as proxy."  
**Ambiguity:** Proof requirements differ: BPL ration card required for some, self-declaration sufficient for migrants.  
**Current Handling:** Engine accepts ration card (AAY/PHH) OR low income as proxy for poor household.  
**Resolution:** Migrants without ration card can use self-declaration + Aadhar as proof. Non-migrants should obtain BPL/PHH ration card from state PDS office if available.

---

### AMB-16: Ujjwala Household Definition for Migrants
**Schemes Affected:** Ujjwala  
**Rule:** "No existing LPG connection in household"  
**Ambiguity:** For migrant families, is 'household' origin family or current household? Origin family may have LPG connection.  
**Current Handling:** Engine cannot verify from profile; flags migrant workers as AMBIGUOUS.  
**Resolution:** If applicant has migrated away from origin household, current household in destination city is treated as separate. If supporting origin family, consult ULB for household definition.

---

### AMB-26: PM-SVANidhi - ULB Discretion on Letter of Recommendation
**Schemes Affected:** PM-SVANidhi  
**Rule:** "Vendors without documentation need Letter of Recommendation from ULB"  
**Ambiguity:** LoR is a valid pathway but ULB discretion applies — LoR not guaranteed.  
**Current Handling:** Engine flags occupation=Street Vendor without documents as AMBIGUOUS. LoR is valid pathway but not guaranteed.  
**Resolution:** Undocumented vendors should approach ULB with supporting evidence (shop location photographs, local resident/shopkeeper references, etc.). LoR is not automatic; ULB may require documentation of vending history.

---

### AMB-28: PM-MUDRA - "Allied to Agriculture" Boundary
**Schemes Affected:** PM-MUDRA  
**Rule:** "Non-farm enterprises only. Allied activities (poultry, dairy, beekeeping) qualify."  
**Ambiguity:** Core crop farming explicitly excluded. Boundary of 'allied activities' unclear — vegetable farming, mushroom cultivation, etc. — where is the line?  
**Current Handling:** Occupation=Farmer flagged AMBIGUOUS. Allied activities (poultry, dairy, beekeeping) return PASS.  
**Resolution:** User should clarify with bank loan officer. Allied activities = production from land not core crop farming. Livestock, horticulture, aquaculture generally qualify; grain farming does not.

---

### AMB-31: Stand-Up India - Closed Enterprise Greenfield Status
**Schemes Affected:** Stand-Up India  
**Rule:** "Applicant must be starting a greenfield enterprise"  
**Ambiguity:** If first enterprise was closed/wound up, is a second enterprise still 'greenfield'? Official guidelines do not explicitly address.  
**Current Handling:** has_existing_enterprise=true → FAIL; closed enterprise → AMBIGUOUS.  
**Resolution:** Officially, greenfield means first-time enterprise. If prior enterprise was registered under Ministry of MSME (has UDYAM registration), closed status may not clear greenfield requirement. Recommend SIDBI verification before application.

---

### AMB-32: Stand-Up India - Corporate Structure Shareholding
**Schemes Affected:** Stand-Up India  
**Rule:** "For non-individual enterprises: 51%+ shareholding by SC/ST or woman"  
**Ambiguity:** Cannot verify corporate structure from profile. Individual applicants verified directly.  
**Current Handling:** For individuals: caste/gender checked directly. Corporate entities require manual verification.  
**Resolution:** Applicants starting companies should provide Articles of Association (AoA) and shareholding pattern. SIDBI verifies 51% equity ownership documentation.

---

### AMB-40: PM Vishwakarma - Part-Time Artisan Definition
**Schemes Affected:** PM Vishwakarma  
**Rule:** "Must be engaged in traditional trade on self-employment basis"  
**Ambiguity:** Part-time artisan who also has another job — does 'on self-employment basis' exclude them?  
**Current Handling:** Engine flags occupation ambiguously matching traditional trade + formal employment indicators as AMBIGUOUS.  
**Resolution:** Primary occupation must be traditional trade. Part-time artisans engaging primarily as employees of others (e.g., artisan in factory) may not qualify. Self-employment with potential clients/own practice preferred.

---

## Category 2: Data Staleness and Verification Issues

### AMB-04: SECC 2011 Database is 15 Years Stale
**Schemes Affected:** Ayushman Bharat, PMAY-G  
**Rule:** "Eligible via SECC 2011 BPL listing or ration card"  
**Ambiguity:** SECC 2011 data 15 years old. Current household status (housing, income, deprivation) may differ significantly from 2011. Database not updated despite demographic shifts.  
**Current Handling:** Engine returns AMBIGUOUS; cannot verify SECC listing from profile. Uses ration card (AAY/PHH) as proxy.  
**Resolution:** Ration card is more current proxy than SECC 2011. Users can request state government to update household status in SECC database, but process is slow. Current ration card status preferred evidence.

---

### AMB-24: APY - EPF Membership Status May Be Stale
**Schemes Affected:** APY  
**Rule:** "Cannot be existing EPF member"  
**Ambiguity:** Informal workers with prior formal stints may have been EPF members technically but are now informal. EPF membership status in government records may be stale.  
**Current Handling:** Engine flags is_epf_member as AMBIGUOUS if occupation suggests informal worker with prior formal history.  
**Resolution:** User should check EPFO portal (https://www.epfoservices.in) for active account status. Discontinued/dormant EPF accounts may not disqualify if income now below threshold.

---

### AMB-25: PM-SYM - Income Verification for Informal Workers
**Schemes Affected:** PM-SYM  
**Rule:** "Monthly income ≤₹15,000 verified"  
**Ambiguity:** No payslip or ITR for informal workers. Self-declaration basis; income boundary cases (₹14k–₹16k) difficult to verify.  
**Current Handling:** Engine accepts self-declared annual_income; flags boundary cases (₹1.6L–₹1.8L) as AMBIGUOUS.  
**Resolution:** Self-declaration is primary mechanism. Applicant should document typical monthly earnings via bank statements (if banking) or neighborhood witnesses (if cash income). Bank may request income proof before final disbursement.

---

## Category 3: State Variation and Decentralized Implementation

### AMB-05: Ayushman Bharat - State-Specific Extensions
**Schemes Affected:** Ayushman Bharat  
**Rule:** "Income eligibility ≤₹3L/₹5L annual (varies by state)"  
**Ambiguity:** Several states extend coverage beyond SECC to additional families. State-specific eligibility extensions vary widely.  
**Current Handling:** Engine returns AMBIGUOUS for income between ₹1.2L–₹3L since state extension coverage varies.  
**Resolution:** Check your state's PM-JAY portal for extended eligibility criteria. Delhi, Maharashtra, Tamil Nadu, etc. have state-specific income caps differing from central ₹3L limit.

---

### AMB-17: NSAP - State BPL List Variation
**Schemes Affected:** NSAP IGNOAPS, IGNWPS, IGNDPS  
**Rule:** "Eligible via state BPL list or AAY/PHH ration card"  
**Ambiguity:** State BPL lists vary in criteria, methodology, and freshness. NSAP uses state lists — no central database. Methodologies differ by state.  
**Current Handling:** Engine uses ration card (AAY/PHH) as proxy; flags 'unknown' as AMBIGUOUS due to state variation.  
**Resolution:** Users should check state social welfare portal. BPL status determined by state government; ration card is simplest proof. Some states use NFSA eligibility lists instead.

---

### AMB-18: NSAP - State Top-Up Variation
**Schemes Affected:** NSAP IGNOAPS, IGNWPS, IGNDPS  
**Rule:** "Central government provides base pension; state top-up varies"  
**Ambiguity:** Top-up amounts vary widely: ₹0 to ₹2,500+/month depending on state. Central amount (₹500/month IGNOAPS, ₹300/month IGNWPS, ₹600/month IGNDPS) is floor.  
**Current Handling:** Engine reports central contribution only. State top-up variation noted in results.  
**Resolution:** Check state social welfare department website for exact monthly pension amount in your state. Some rich states provide multiples of central pension.

---

### AMB-19: NSAP IGNOAPS - State Interpretation of "No Other Pension"
**Schemes Affected:** NSAP IGNOAPS  
**Rule:** "Applicant receives no other pension or financial assistance"  
**Ambiguity:** State interpretation varies. Some states exclude family support, others only formal pensions. No single definition.  
**Current Handling:** is_govt_employee=true → FAIL. Pension from other sources → AMBIGUOUS.  
**Resolution:** "No other pension" traditionally means formal government pension only (not family support per AMB-44). Consult district social welfare office for state interpretation. Family remittances from children do not disqualify.

---

### AMB-21: NSAP IGNWPS - Age Range Variation
**Schemes Affected:** NSAP IGNWPS  
**Rule:** "Widow must be 40+ years old; 80+ gets higher rate"  
**Ambiguity:** Central guideline is 40–79 with 80+ higher rate. Some states have different entry points (e.g., 35+ or 45+).  
**Current Handling:** Engine uses central rule: age ≥40 for eligibility.  
**Resolution:** Check state social welfare portal for exact age eligibility. Central guideline is 40; some states more generous. If age 35–39, check state-specific IGNWPS variant.

---

### AMB-36 & AMB-37: NFSA - State-Specific AAY/PHH Criteria and Coverage
**Schemes Affected:** NFSA  
**Rule:** "Eligible for AAY (poorest of poor) or PHH (remaining population) per state criteria"  
**Ambiguity:** (AMB-36) AAY identification criteria vary by state. State determines who qualifies as 'poorest of poor' for AAY vs PHH. (AMB-37) PHH inclusion/exclusion criteria entirely state-specific. Central NFSA sets coverage percentage (75% rural, 50% urban) but states choose who is included.  
**Current Handling:** Engine uses income and vulnerability proxies as signals; always flags as AMBIGUOUS due to state variation.  
**Resolution:** Check your state NFSA portal (under state PDS office) for eligibility. Eligibility criteria are state-determined. Apply at local ration shop or gram panchayat with identity/residence proof.

---

### AMB-38: NFSA - One Nation One Ration Card (ONORC) Portability
**Schemes Affected:** NFSA  
**Rule:** "Ration card portability enabled across states via ONORC"  
**Ambiguity:** ONORC implementation varies. Migrant workers may face access issues despite portability rules.  
**Current Handling:** Engine notes ONORC availability; flags migrant workers as AMBIGUOUS for ration card portability.  
**Resolution:** Migrant workers should link ration card to Aadhar for ONORC portability. Not all states fully implement ONORC yet. Check destination state's PDS portal. May face delays in first month of migration.

---

### AMB-39: NFSA - Head of Family Gender Requirement
**Schemes Affected:** NFSA  
**Rule:** "Head of family on ration card must be eldest woman member (18+); male only if no adult woman"  
**Ambiguity:** This requirement affects who can apply but is not an eligibility gate. Household eligibility unchanged.  
**Current Handling:** Noted in results; female head of family preferred for ration card application.  
**Resolution:** If household has adult woman ≥18, register under her name for NFSA ration card. Improves social welfare access (women's schemes prioritize female heads).

---

### AMB-42: PM Vishwakarma - Local Gram Panchayat/ULB Verification Backlogs
**Schemes Affected:** PM Vishwakarma  
**Rule:** "Registration requires gram panchayat or ULB verification"  
**Ambiguity:** Verification step may have local backlogs or varying verification criteria by panchayat.  
**Current Handling:** Cannot determine from profile; noted as verification step required.  
**Resolution:** User should submit application to local gram panchayat or ULB trade authority with supporting documents (business license, photographs, testimonials). Verification timeline varies: 2–4 weeks typical.

---

### AMB-43: PMAY-U - States Can Redefine EWS/LIG/MIG Income Criteria
**Schemes Affected:** PMAY-U  
**Rule:** "EWS ≤₹3L, LIG ₹3–6L, MIG ₹6–9L annual household income"  
**Ambiguity:** States can redefine EWS income ceiling with MoHUA concurrence. Central defaults of ₹3L/₹6L/₹9L are defaults only.  
**Current Handling:** Engine uses ₹3L/₹6L/₹9L as central defaults. Flags boundary cases (within ±20% of thresholds) as AMBIGUOUS.  
**Resolution:** Check your state's PMAY-U 2.0 portal or contact state housing department. Some states have higher income ceilings (e.g., Maharashtra EWS ≤₹5L).

---

## Category 4: Definitional Exceptions and Overlaps

### AMB-20: NSAP IGNWPS - Remarriage Revokes Pension (RESOLVED)
**Schemes Affected:** NSAP IGNWPS  
**Rule:** "Widow pension continues only during widowhood"  
**Ambiguity (RESOLVED):** Central IGNWPS guidelines explicitly revoke pension on remarriage.  
**Current Handling:** marital_status=married after widowhood → FAIL.  
**Resolution:** **RESOLVED** — Central IGNWPS explicitly revokes pension on remarriage. State implementation uniform. Widow must remain unmarried to continue receiving pension.

---

### AMB-22: NSAP IGNDPS - 40–79% Disability Excluded from Central Scheme
**Schemes Affected:** NSAP IGNDPS  
**Rule:** "Central IGNDPS requires ≥80% disability"  
**Ambiguity:** Central IGNDPS excludes 40–79% disabled. However, states run separate schemes for 40–79%.  
**Current Handling:** disability_percent < 80 → FAIL for central IGNDPS. Engine notes state schemes may cover 40–79%.  
**Resolution:** Central IGNDPS pension only for ≥80% disability. Check state social welfare department for separate schemes covering 40–79% disabled (various state-specific names: VRIDDHI in some states, etc.).

---

### AMB-23: NSAP - Dual Eligibility (Disabled Widow)
**Schemes Affected:** NSAP IGNDPS, IGNWPS  
**Rule:** "One beneficiary per scheme; disabled widow could theoretically qualify for both"  
**Ambiguity:** No clear central guideline on whether both pensions can be claimed simultaneously.  
**Current Handling:** Engine flags as AMBIGUOUS; shows both as potentially eligible with note.  
**Resolution:** Disabled widows should check state social welfare office. In practice, most states allow single pension selection; some allow higher of two amounts or cumulative benefits. State-dependent.

---

### AMB-27: PM-SVANidhi - No March 2020 Cut-Off for New Vendors (RESOLVED)
**Schemes Affected:** PM-SVANidhi  
**Rule:** "Vendor eligibility"  
**Ambiguity (RESOLVED):** Previously believed to have March 2020 cut-off for vendor identification. This was incorrect.  
**Current Handling:** No cut-off date check. New vendors eligible via Category C/D LoR (Letter of Recommendation) route.  
**Resolution:** **RESOLVED** — PM-SVANidhi has no March 2020 cut-off. New vendors eligible if they can obtain LoR from ULB. Updated guidance: vendors starting post-2020 can apply with LoR pathway.

---

### AMB-30: PMEGP - "One Per Family" Rule Definition
**Schemes Affected:** PMEGP  
**Rule:** "Only one enterprise per family eligible"  
**Ambiguity:** 'Family' defined as self and spouse. Multiple adult children starting separate enterprises — unclear if each counts as separate family.  
**Current Handling:** Previous_scheme_loans containing PMEGP → AMBIGUOUS rather than definitive FAIL.  
**Resolution:** For individual applicants: PMEGP allows one enterprise per self-spouse pair. Adult children (even if living with parents) may be separate family units. Consult KVIC/SIDBI on family definition for your structure.

---

### AMB-33: Sukanya Samriddhi - Blended Family Limits
**Schemes Affected:** Sukanya Samriddhi  
**Rule:** "Maximum 2 accounts per family; one account per girl child"  
**Ambiguity:** Blended families (step-children, adopted children) — complicated family limit enforcement.  
**Current Handling:** Engine flags previous SSY accounts as AMBIGUOUS for blended families.  
**Resolution:** Each biological/legally adopted girl child gets one account. "Family" defined as parents + all dependent children. Consult post office for blended family documentation requirements.

---

### AMB-34 & AMB-35: PMMVY - Miscarriage/Stillbirth and Multiple Births (RESOLVED & AMBIGUOUS)
**Schemes Affected:** PMMVY  
**(AMB-34: RESOLVED)** "Does miscarriage/stillbirth count as 'first birth' for PMMVY eligibility?"  
**Current Handling:** Miscarriage/stillbirth treated as fresh case — does NOT count as first birth.  
**Resolution:** **RESOLVED** — PMMVY 2.0 guidelines (Mission Shakti, effective 01.04.2022) explicitly treat miscarriage/stillbirth as fresh case. Woman can claim ₹5,000 for future first pregnancy.

**(AMB-35: AMBIGUOUS)** "Twins/triplets in second pregnancy — if one or more are girls, incentive applies?"  
**Current Handling:** is_pregnant_or_lactating=true with num_children≥2 flagged AMBIGUOUS for possible second child incentive.  
**Resolution:** Multiple births with at least one girl child may qualify for second child incentive. Consult state health department for exact implementation. PMMVY 2.0 allows second child incentive if at least one child is girl.

---

### AMB-41: PM Vishwakarma - "Availed" vs "Outstanding" Loan History
**Schemes Affected:** PM Vishwakarma  
**Rule:** "Cannot have availed credit from PMEGP/PM-SVANidhi/PM-MUDRA recently"  
**Ambiguity:** Scheme uses 'availed' (taken) not 'outstanding' (unpaid). Fully repaid loans still count as disqualifying.  
**Current Handling:** Engine flags previous_scheme_loans containing [pmegp, pm_svanidhi, pm_mudra] as AMBIGUOUS with note that repaid loans may still disqualify.  
**Resolution:** Even if previous loan is repaid, recent history disqualifies. "Recent" typically means last 3–5 years. Consult PM Vishwakarma portal for exact lookback period per district.

---

### AMB-45: PM-KISAN - Class IV/Group D Government Employee Exception
**Schemes Affected:** PM-KISAN  
**Rule:** "Excludes government employees except Class IV / Multi-Tasking Staff / Group D workers"  
**Ambiguity:** PM-KISAN excludes govt employees BUT explicitly carves out Class IV / Multi-Tasking Staff / Group D workers (peons, sweepers, gardeners). Engine cannot distinguish Group D from other govt employees.  
**Current Handling:** is_govt_employee=true → FAIL with note that Group D employees may still qualify.  
**Resolution:** If you are Group D/Multi-Tasking Staff employed by government, you may be eligible despite engine FAIL. Self-verify at pmkisan.gov.in using your employee ID. Check 'verify status' tool on official portal.

---

## Summary Table: Ambiguities by Resolution Status

| Status | Count | Examples |
|--------|-------|----------|
| **Resolved** | 3 | AMB-20 (Remarriage), AMB-27 (No SVANidhi cut-off), AMB-34 (Miscarriage) |
| **Partially Resolved** | 2 | AMB-44 (Family support clarified), AMB-41 (Repaid loans still disqualify) |
| **Requires User Verification** | 20 | Land ownership, income thresholds, state-specific criteria |
| **System Ambiguity Handling** | 20 | Flagged as AMBIGUOUS; user advised to contact local authority |
| **Total Documented** | 45 | Across 20 schemes |

---

## Engine Ambiguity Handling Strategy

1. **Flags as AMBIGUOUS:** Rule condition cannot be definitively evaluated from profile fields. User shown gap with explanation.
2. **Suggests Contact Point:** Local Gram Panchayat (rural), ULB (urban), or scheme-specific helpline.
3. **Provides Proxy Evidence:** Where possible, suggests alternative documentation or verification method.
4. **Notes State Variation:** Ambiguities marked with state-specific guidance when applicable.
5. **Reduces Confidence Score:** AMBIGUOUS rule evaluations reduce scheme match confidence by 15–25% each.

---

## Recommended User Journey for Ambiguous Results

1. **Engine returns AMBIGUOUS for a scheme.**
2. **User reads gap explanation** (e.g., "Land ownership unclear — leased land status ambiguous").
3. **User follows suggested contact point** (e.g., "Consult Patwari for land record verification").
4. **User collects supporting document** (e.g., land purchase deed, ration card, affidavit).
5. **User resubmits or applies with combined document set.**

---

**Document Version:** April 2026  
**Last Updated:** When any new ambiguity is discovered or existing one is resolved.  
**Feedback:** Report new ambiguities or resolutions to the project via GitHub Issues.
