# Kalam Deliverable 5: Conversational Interface Documentation

## Overview

This document describes the real-time conversational interface as currently implemented in Kalam. The system manages stateful multi-turn dialogue in Hinglish/English, collecting a UserProfile through natural language without external NLU APIs. This document reflects the current post-April 2026 state, after all recent conversation engine updates.

---

## Architecture: In-Memory Session Management

**Location:** `src/conversation/engine.py`

### Session State Model

```python
@dataclass
class ConversationState:
    session_id: str                      # UUID (128-bit URL-safe token)
    profile: dict                        # Collected user profile data
    skipped: set                         # Fields user chose to skip
    contradictions_seen: list            # Logged inconsistencies
    turn: int                            # Number of conversation turns
    last_question: Optional[str]         # Last question asked to user
    last_question_field: Optional[str]   # Which profile field was last question about
    created_at: float                    # Unix timestamp (for TTL eviction)
    done: bool                           # True when >=5 mandatory fields collected
```

### Session Lifecycle

```
1. User starts chat
   ↓
2. GET /api/new-session
   ↓
3. Engine creates ConversationState in _SESSIONS[session_id]
   ↓
4. Session lives for TTL = 3600 seconds (1 hour)
   ↓
5. On each POST /api/chat, session accessed/updated
   ↓
6. If now - created_at > 3600 → evicted from memory
   ↓
7. OR user clicks "Reset" → reset_session() called
```

### In-Memory Store

```python
_SESSIONS: dict[str, ConversationState] = {}  # Global in-process storage
_SESSION_TTL = 3600  # 1 hour (sufficient for typical Render free tier single-process)

def get_or_create_session(session_id: Optional[str] = None) -> ConversationState:
    now = time.time()
    # Evict expired sessions
    expired = [k for k, v in _SESSIONS.items() if now - v.created_at > _SESSION_TTL]
    for k in expired:
        del _SESSIONS[k]
    
    if session_id and session_id in _SESSIONS:
        return _SESSIONS[session_id]
    
    sid = session_id or secrets.token_urlsafe(16)
    state = ConversationState(session_id=sid)
    _SESSIONS[sid] = state
    return state
```

**Implications:**
- Sessions **not persisted** to database (sufficient for Render free tier).
- On server restart: all sessions lost (acceptable for dev/demo).
- Max concurrent sessions: ~100–200 before memory pressure (Render free tier ~512 MB RAM).
- Single-process Uvicorn (default Render free tier) → no cross-process session sync needed.

---

## Field Extraction Priority

**Location:** `src/conversation/follow_up.py`

### Mandatory Fields

```python
MANDATORY_FIELDS = {
    "age", "state", "is_urban", "caste_category", "gender",
    "annual_income", "occupation", "family_size",
    "has_bank_account", "has_aadhaar", "is_aadhaar_linked",
}
```

**Total Mandatory:** 11 fields  
**Done-State Trigger:** ≥5 mandatory fields collected (lower threshold due to complexity of collecting all 11 manually)

### Field Priority Order

Fields asked in this order (by scheme coverage impact):

```python
FIELD_PRIORITY: list[tuple[str, str]] = [
    ("has_aadhaar", "Kya aapke paas Aadhaar card hai? (Do you have an Aadhaar card?)"),
    ("has_bank_account", "Kya aapka bank account hai? (Do you have a bank account?)"),
    ("is_urban", "Aap gaon mein rehte hain ya shehar mein? (Do you live in a village or city?)"),
    ("state", "Aap kis state mein rehte hain? (Which state do you live in?)"),
    ("annual_income", "Aapki saalana income kitni hai (approx)? (What is your annual income approx?)"),
    ("caste_category", "Aapki category kya hai — General, OBC, SC, ya ST?"),
    ("gender", "Aap purush hain, mahila hain, ya transgender? (Male, Female, or Transgender?)"),
    ("occupation", "Aap kya kaam karte hain? (What is your occupation?)"),
    ("family_size", "Aapke ghar mein kitne log hain? (How many people in your family?)"),
    ("is_aadhaar_linked", "Kya aapka Aadhaar bank account se linked hai?"),
    ("land_ownership", "Kya aapke paas zameen hai? Apni, kiraye ki, ya koi nahi?"),
    ("marital_status", "Aap shaadi-shuda hain? (What is your marital status?)"),
    ("has_ration_card", "Kya aapke paas ration card hai? (AAY/PHH/none?)"),
    ("disability_percent", "Kya aapko koi disability hai? Kitne percent?"),
]
```

**Rationale:**
- Aadhaar + Bank Account first (required by ~80% of schemes via DBT).
- Urban/Rural + State (filters ~90% of scheme eligibility).
- Income, Caste, Gender, Occupation (partition across remaining schemes).
- Family Size, Land Ownership, Marital Status (optional but improves matches).
- Disability (small subset of schemes).

---

## Hinglish NLP Pattern Matching

**Location:** `src/conversation/engine.py` (_extract_fields function)

The engine uses **pure regex** (no external API) to extract fields from Hinglish/English input. All patterns are in English and Devanagari script simultaneously.

### Extraction Patterns

#### Age
**Trigger Phrases:** "umar", "age", "saal", "years", "varsh", "साल", "उम्र"  
**Examples:**
- "meri umar 35 hai" → age=35
- "35 saal" → age=35
- "I'm 40 years old" → age=40
- "उम्र 28 है" → age=28

**Regex:**
```python
r'(?:umar|age|saal|years?|varsh|साल|उम्र)[^\d]*(\d{1,3})'
r'|(\d{1,3})\s*(?:saal|years?\s*old|varsh|साल)'
```

**Boundary Check:** 5 < age < 120 (rejects invalid ages)

#### Income
**Trigger Phrases:** "lakh", "hazar", "thousand", "लाख", "हजार", or plain numbers in income context  
**Examples:**
- "3 lakh" → 300,000
- "80 hazar" → 80,000
- "₹2,50,000" → 250,000
- "1.5 lakh" → 150,000

**Regex:**
```python
r'(\d+(?:\.\d+)?)\s*(?:lakh|lacs?|lakhs?|लाख)'  # → * 100,000
r'(\d+)\s*(?:hazaar|hazar|thousand|हज़ार|हजार|k\b)'  # → * 1,000
```

**Context Bonus:** If last_question was about income, extract first plain 4–8 digit number as income.

#### Gender
**Patterns (Female):**
- "main ek mahila hoon", "aurat", "lady", "female", "महिला", "औरत", "beti", "ladki"
- "she", "her"

**Patterns (Male):**
- "main ek aadmi hoon", "purush", "mard", "man", "पुरुष", "आदमी", "ladka"
- "he", "his", "mr."

**Patterns (Transgender):**
- "transgender", "kinnar", "किन्नर", "third gender"

#### Urban/Rural
**Rural:** "gaon", "village", "gram", "rural", "gramin", "dehat", "गाँव", "गांव", "देहात"  
**Urban:** "shehar", "city", "town", "urban", "शहर", "नगर", "metro"

#### State
**STATE_MAP:** 28 states + UTs with fuzzy matching:
- "UP" or "Uttar Pradesh" or "u.p." → "Uttar Pradesh"
- "Bihar" → "Bihar"
- "Rajasthan" → "Rajasthan"
- "Delhi" or "Dilli" or "New Delhi" → "Delhi"
- "Jammu & Kashmir" or "J&K" or "J & K" → "Jammu & Kashmir"
- (26 more states)

#### Family Size
**Trigger:** "log", "member", "pariwar", "family", "sadasya", "jankar", "जन", "परिवार", "अंग"  
**Examples:**
- "4 log ghar mein" → family_size=4
- "5 member family" → family_size=5
- "हमारे घर में 3 लोग हैं" → family_size=3

**Boundary Check:** 1 ≤ family_size ≤ 30

#### Land Ownership
**Free-form:** "apni zameen", "leased land", "sharecrop", "own property", "किराए की जमीन"  
**Values matched:**
- "owns" / "own" / "meri zameen"
- "leases" / "lease" / "kiraye ki"
- "sharecrop" / "samjhautaa"
- "none" / "no land"

#### Occupation
**Free-form text:** "farmer", "construction worker", "street vendor", "teacher", "driver"  
**Normalized against occupation enum** (case-insensitive, fuzzy matching allowed)

### Context-Aware Extraction

If `last_question_field` is set, extractor optimizes parsing:

```python
if last_question and re.search(r'income|amdani|saalana|कमाई', last_question, re.I):
    # User is answering income question
    # Look for plain numbers that would be income
    raw = t.replace(',', '')
    nums = re.findall(r'\b(\d{4,8})\b', raw)
    if nums:
        extracted["annual_income"] = int(nums[0])

elif last_question and re.search(r'family|ghar|pariwar|kitne', last_question, re.I):
    # User is answering family size question
    nums = re.findall(r'\b(\d{1,2})\b', t)
    if nums:
        n = int(nums[0])
        if 1 <= n <= 30:
            extracted["family_size"] = n
```

---

## Skip and "Don't Know" Handling

**Location:** `src/conversation/engine.py`

### Skip Pattern Detection

```python
_SKIP_PATTERNS = re.compile(
    r"""^(
        pata\s*nahi | nahi\s*pata | pata\s*nahin | nahin\s*pata |
        don'?t\s*know | dont\s*know | no\s*idea | not\s*sure |
        skip | na | naa | \? | idk | hmm | huh |
        mujhe\s*nahi\s*pata | maloom\s*nahi | yaad\s*nahi |
        kya\s*pata | nahi\s*maloom
    )$""",
    re.VERBOSE | re.IGNORECASE,
)

def is_skip(text: str) -> bool:
    return bool(_SKIP_PATTERNS.match(text.strip()))
```

**Matched Inputs:**
- English: "don't know", "skip", "no idea", "idk", "hmm"
- Hindi: "pata nahi", "maloom nahi", "yaad nahi", "kya pata"

### Engine Response to Skip

When user says "pata nahi":
1. Field NOT added to profile (remains None).
2. Logged in `skipped` set: `state.skipped.add("annual_income")`.
3. Engine asks next question from FIELD_PRIORITY (if ≥5 mandatory fields not reached).
4. If ≥5 mandatory fields already collected → triggers done-state (shows results).

---

## Contradiction Detection

**Location:** `src/conversation/contradiction.py`

Engine detects logical inconsistencies and logs them (for human review, doesn't fail):

**Contradiction Rules:**

```python
contradictions = [
    {
        "condition": is_govt_employee and annual_income < 150000,
        "message": "Earlier you said govt employee, but income seems low for govt job. Clarify?"
    },
    {
        "condition": is_income_tax_payer and annual_income < 250000,
        "message": "Income below ITR threshold (₹2.5L) but marked as tax payer. Verify?"
    },
    {
        "condition": has_motorized_vehicle and annual_income < 50000,
        "message": "You have motorized vehicle but income very low. Possible?"
    },
    {
        "condition": occupation in ["Software Engineer", "Data Analyst"] and is_urban == false,
        "message": "Tech occupation in rural area unlikely. Did you mean something else?"
    },
    {
        "condition": land_area_hectares > 10 and annual_income < 100000,
        "message": "Large land holding (>10 hectares) but low income. Farm productive?"
    },
]
```

**Engine Behavior:**
- Logs contradiction in `state.contradictions_seen`.
- Asks follow-up: "Earlier you said X, but now I hear Y. Could you clarify?"
- Does **NOT fail or reject** profile (user may have valid reason).
- Reduces confidence score by 5% per contradiction.

---

## Done-State Logic

**Location:** `src/conversation/engine.py`

### Done-State Trigger

Profile marked `done=True` when:

```python
missing = missing_mandatory_fields(profile_data)
if len(missing) <= (11 - 5):  # 11 mandatory fields, need >=5
    state.done = True
    return render_results(profile)
```

**Translation:**
- Mandatory fields: 11 (age, state, is_urban, caste, gender, income, occupation, family_size, bank, aadhaar, aadhaar_linked)
- Done-state threshold: ≥5 fields collected
- Done-state trigger: ≤6 fields missing

### Why 5 Fields Minimum?

Real-world data quality: Collecting all 11 mandatory fields from rural semi-literate users is difficult. Threshold of 5 is pragmatic:
- Aadhaar + Bank Account (2/5) → filters ~80% of schemes via DBT
- Urban/Rural + State (2/5 more) → filters by geography
- One more (income, caste, or gender) → provides basic scheme partition

With just these 5, engine can show meaningful results and gaps.

---

## Audio/TTS Integration

**Location:** Frontend: `web/static/js/app.js`; Backend: `/api/tts` endpoint

### Server-Side HuggingFace MMS

**Endpoint:** `POST /api/speak`

```python
@app.post("/api/speak")
async def speak(request: Request):
    """
    Proxies text to HuggingFace Inference API (facebook/mms-tts-hin).
    Returns audio/flac. LRU-cached (maxsize=200). Rate-limited 20 req/60s per IP.
    Falls back gracefully — returns 503 if HUGGINGFACE_API_KEY not set.
    """
```

**Implementation:** Calls HuggingFace **Inference API** (cloud endpoint) — NOT a local model download. This means:
- No 1 GB model download, no cold-start penalty for the model itself
- Response time: ~1–3 seconds per request on HuggingFace free tier
- Text preprocessing: ₹ → "रुपये", emojis stripped, symbols normalised before sending
- Audio cached as blob URLs in a JS Map — repeated taps replay instantly without re-fetching
- Rate-limited at 20 requests / 60 seconds per IP on the server endpoint

**Hindi-only in chat:** The `hindiOnly()` function splits bot messages on the `·` separator and reads only the Hindi portion (first part). Hinglish chat messages without `·` are read as-is.

**Requirement:** `HUGGINGFACE_API_KEY` must be set in Render Environment Variables. Without it, the endpoint returns 503 and the client silently falls back to Web Speech — the app is fully functional either way.

**Retry Logic:**
- 3x retry with 20s timeout each.
- If all retries fail: fallback to Web Speech API (client-side).

### Client-Side Web Speech API Fallback

**Location:** `web/static/js/app.js`

```javascript
async function speakHindi(text) {
    const cleaned = hindiOnly(text);  // extract Hindi portion before '·'
    try {
        // Try server TTS first (/api/speak)
        const response = await fetch('/api/speak', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: cleaned })
        });
        if (!response.ok) throw new Error('TTS server unavailable');
        const audioBlob = await response.blob();
        const audioUrl = URL.createObjectURL(audioBlob);
        _ttsCache.set(cleaned, audioUrl);  // cache for instant replay
        new Audio(audioUrl).play();
    } catch (error) {
        // Silent fallback to Web Speech API
        const utterance = new SpeechSynthesisUtterance(cleaned);
        utterance.lang = 'hi-IN';
        utterance.rate = 0.85;
        speechSynthesis.cancel();
        setTimeout(() => speechSynthesis.speak(utterance), 50); // Chrome async fix
    }
}
```

**Chrome browser workarounds implemented:**
- `speechSynthesis.cancel()` is async — 50ms delay before `speak()` prevents silent cancellation
- Periodic pause/resume keepalive prevents Chrome's 30-second idle cutoff
- iOS Safari: utterance built synchronously inside user-gesture handler
- Voice-load race condition: retry on `onend` with `_started` flag

**Web Speech API Characteristics:**
- Works **offline** (no server call).
- Voice quality lower than HuggingFace.
- Latency: <500ms (instant).
- Browser support: Chrome, Edge, Firefox (limited on Safari).
- Cross-device: Android Chrome, iOS Safari (limited).

### UI Features

**Auto-Speak:**
- Every bot message is automatically spoken on render (HuggingFace MMS primary, Web Speech fallback).
- Hindi-only: `hindiOnly()` extracts the Devanagari portion before speaking — avoids reading English labels aloud.

**Tap-to-Replay:**
- User taps any bot message bubble to replay its audio.
- Blob URLs cached in a JS Map so replay is instant without re-fetching.

**Animated Thinking Indicator:**
- While the bot is processing, an animated dots indicator (`·` → `··` → `···`) renders via CSS animation.
- Gives clear visual feedback so users on slow connections know the system is working.

**Per-Sentence Rendering:**
- Bot messages are split into `<span>` blocks per sentence with smooth scroll.
- Prevents a wall of text; each sentence appears with a short delay for readability.

**Bilingual UI Text (not Hinglish):**
- All page chrome (labels, buttons, status messages) uses proper Hindi · English format.
- Hinglish is used only inside the chat conversation itself.
- Examples: "पढ़कर सुनाएं / Read aloud", "नई बात शुरू हो रही है… / Starting over…", "सर्वर शुरू हो रहा है… / Server starting…"

**🔊 Speak buttons on results page:**
- Every scheme card, benefit line, and application step in the results page also has a 🔊 button (not just the chat).

---

## Cold-Start Handling

**Render Free Tier Challenge:** Application spins down if no traffic for 15 minutes. First request after spin-down incurs 20–40s startup latency.

### Mitigation Strategy

**GitHub Actions Cron Job:**
```yaml
name: Keep Render Alive
on:
  schedule:
    - cron: '*/14 * * * *'  # Every 14 minutes

jobs:
  wake:
    runs-on: ubuntu-latest
    steps:
      - name: Wake Render
        run: curl https://kalam-ac7c.onrender.com  # pings root, no /health endpoint needed
```

**Endpoint:** `/health`
```python
@app.get("/health")
async def health_check():
    return {"status": "ok"}
```

**Effect:**
- Server pinged every 14 minutes.
- Keeps Render instance warm (no cold start on real user requests).
- Cron job runs free on GitHub Actions.

---

## Conversation Flow Diagram

```
User opens chat.html
    ↓
JavaScript: GET /api/chat/opening → session_id + greeting
    ↓
User types: "Hello, I'm a farmer from UP"
    ↓
POST /api/chat { session_id, message }
    ↓
Engine._extract_fields() → extracts: occupation="farmer", state="UP"
    ↓
Profile updated: { occupation: "farmer", state: "UP" }
    ↓
missing_mandatory_fields() → 9 fields still missing
    ↓
done == False (only 2/5 fields)
    ↓
get_next_question() → returns question about Aadhaar (highest priority)
    ↓
Response: { reply, extracted, profile, done, session_id }
    ↓
User sees question in chat + auto-plays audio (if TTS on)
    ↓
User: "Haan, mere paas Aadhaar hai" (Yes, I have Aadhaar)
    ↓
Engine extracts: has_aadhaar=true
    ↓
Profile: { occupation, state, has_aadhaar } (3/5)
    ↓
Continue asking until 5 fields collected...
    ↓
done=true when >=5 fields
    ↓
[CTA button submits hidden form → POST /results with profile fields]
    ↓
Rule engine evaluates all 20 schemes
    ↓
Returns: { eligible_schemes, likely_eligible_schemes, gaps, next_steps }
    ↓
Chat displays results in Hindi/English with action buttons
```

---

## Session Reset

**Endpoint:** `POST /api/reset`

```python
@app.post("/api/reset")
async def reset_session(request: ResetRequest):
    state = reset_session(request.session_id)
    return { "session_id": state.session_id, "message": "Session reset" }
```

**User Action:** Clicks "Start Over" button  
**Effect:** New ConversationState created; old session cleared from memory

---

## Current Limitations & Future Improvements

### Current Limitations

1. **No Database Persistence:** Sessions lost on server restart. Acceptable for low-traffic, high-user-churn demo.
2. **Single-Process:** No horizontal scaling. Max ~100–200 concurrent sessions.
3. **Hinglish Only:** No Tamil, Telugu, Marathi, Kannada, etc.
4. **Regex-Based Extraction:** Misses complex sentences. Not as robust as LLM-based NLU.
5. **No User History:** Each session isolated; no learning across sessions.

### Planned Future Enhancements

1. **PostgreSQL Persistence:** Move sessions to database for durability + horizontal scaling.
2. **Multi-Language:** Add regional language support (Tamil, Telugu, etc.).
3. **LLM Integration:** Replace regex NLP with Claude/GPT for free-form understanding (if API rate limits affordable).
4. **User Accounts:** Optional login for session history + scheme status tracking.
5. **Feedback Loop:** Track which schemes users actually apply for; use to calibrate engine.

---

**Document Version:** April 2026  
**Last Updated:** Post-conversation engine fixes (Apr 16, 2026)  
**Testing:** 158 tests passing (92 unit + 50 standard profiles + 16 misc, including 10 adversarial edge cases)
