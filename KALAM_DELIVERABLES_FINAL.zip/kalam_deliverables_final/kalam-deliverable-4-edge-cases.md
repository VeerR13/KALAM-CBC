# Kalam Deliverable 4: Adversarial Edge Cases

## Overview

This document catalogs the 10 adversarial test profiles in `tests/fixtures/profiles/edge_*.json`. Each profile tests a specific edge case that challenged the rule engine design. Profiles are used for regression testing and to validate engine behavior on corner cases.

---

## Edge Case 1: Remarried Widow

**File:** `tests/fixtures/profiles/edge_01_remarried_widow.json`

**Profile:**
```json
{
  "age": 52, "state": "UP", "is_urban": false, "caste_category": "OBC",
  "gender": "F", "annual_income": 48000, "occupation": "agricultural_labourer",
  "family_size": 3, "has_bank_account": true, "has_aadhaar": true,
  "is_aadhaar_linked": true, "marital_status": "married",
  "has_ration_card": "AAY", "is_govt_employee": false, "is_income_tax_payer": false
}
```

**Edge Case Being Tested:**
- 52-year-old widow who has **remarried**. Should have been eligible for NSAP-IGNWPS (widow pension) before remarriage; now should be ineligible.

**Expected Matches:**
- **INELIGIBLE:** NSAP-IGNWPS (remarriage revokes widow pension per AMB-20, now resolved).
- **ELIGIBLE/LIKELY_ELIGIBLE:** NSAP-IGNOAPS (old age, BPL status meets criteria).
- **LIKELY_ELIGIBLE:** PMAY-G (rural, BPL, age qualifies).
- **LIKELY_ELIGIBLE:** NFSA (BPL, age, vulnerable category).
- **LIKELY_ELIGIBLE:** Ujjwala (female, BPL, but already married — may have LPG already).

**Engine Behavior:**
- Correctly evaluates marital_status=married → FAIL for IGNWPS (widow-only scheme).
- Still eligible for old age pension (IGNOAPS).
- Tests: Marital status exclusions work correctly.

**Why It's Adversarial:**
- Tests whether engine correctly distinguishes between "widow now married" (ineligible for IGNWPS) vs. "widow eligible for IGNOAPS".
- Regression risk: If rule logic breaks, widow pensions might be awarded to remarried women (policy violation).

---

## Edge Case 2: Leased Farmer

**File:** `tests/fixtures/profiles/edge_02_leased_farmer.json`

**Profile:**
```json
{
  "age": 38, "state": "Bihar", "is_urban": false, "caste_category": "SC",
  "gender": "M", "annual_income": 70000, "occupation": "farmer",
  "family_size": 5, "has_bank_account": true, "has_aadhaar": true,
  "is_aadhaar_linked": true, "land_ownership": "leases", "land_area_hectares": 0.66,
  "has_ration_card": "PHH", "is_govt_employee": false, "is_income_tax_payer": false
}
```

**Edge Case Being Tested:**
- Farmer with **leased** land (0.66 hectares). PM-KISAN official rule: land must be owned, not leased. AMB-01 codifies this ambiguity.

**Expected Matches:**
- **AMBIGUOUS:** PM-KISAN (land_ownership=leases → AMBIGUOUS per AMB-01; flagged for Patwari verification).
- **LIKELY_ELIGIBLE:** MGNREGA (rural, age ≥18, no other conditions).
- **LIKELY_ELIGIBLE:** PMAY-G (rural, BPL/PHH, low income, SC category, can potentially access land allotment).
- **LIKELY_ELIGIBLE:** NFSA (BPL, SC, rural).

**Engine Behavior:**
- KISAN rule evaluation: land_ownership=leases → checks against `ambiguous_values` → returns AMBIGUOUS (not FAIL).
- Confidence for PM-KISAN reduced (50–60%) due to ambiguity.
- Other schemes properly evaluate despite leased land (MGNREGA/PMAY-G do not require ownership).

**Why It's Adversarial:**
- PM-KISAN is highly popular; false negatives hurt real farmers. Ambiguity handling must be precise.
- Tests whether engine **flags ambiguous** (correct) rather than **hard-failing** (incorrect).
- Regression risk: If AMBIGUOUS logic breaks, valid leased farmers incorrectly rejected.

---

## Edge Case 3: No Bank Account

**File:** `tests/fixtures/profiles/edge_03_no_bank_account.json`

**Profile:**
```json
{
  "age": 42, "state": "Odisha", "is_urban": false, "caste_category": "ST",
  "gender": "F", "annual_income": 95000, "occupation": "farmer",
  "family_size": 4, "has_bank_account": false, "has_aadhaar": true,
  "is_aadhaar_linked": false, "land_ownership": "owns", "land_area_hectares": 1.5,
  "has_ration_card": "PHH", "is_govt_employee": false, "is_income_tax_payer": false
}
```

**Edge Case Being Tested:**
- Farmer who **owns land** but has **NO bank account**. Many schemes (PM-KISAN, PMAY-G, MGNREGA) require DBT which requires a bank account.

**Expected Matches:**
- **INELIGIBLE:** PM-KISAN (missing has_bank_account → mandatory field → MISSING/FAIL for KISAN-R03).
- **LIKELY_ELIGIBLE:** PMAY-G (rural, ST, BPL, owns land → but missing bank account is gap; user needs to open bank first — prerequisite PMJDY).
- **ELIGIBLE/LIKELY_ELIGIBLE:** MGNREGA (no bank account required for job card registration, though wages paid via bank).
- **LIKELY_ELIGIBLE:** NSAP-IGNDPS or IGNOAPS (if age/disability criteria met; pension may not require bank account in some states).

**Engine Behavior:**
- Prerequisite dependency: PMJDY should be first recommended (open bank account).
- Gap analysis shows: "Missing: Bank account required for DBT transfer. Action: Apply for PMJDY first."
- Engine correctly identifies bank account as blocker for DBT-dependent schemes.

**Why It's Adversarial:**
- Tests prerequisite scheme logic. If broken, engine might recommend schemes impossible to claim without bank account.
- Tests whether MISSING mandatory field blocks scheme (reduces confidence to LIKELY_ELIGIBLE, not ELIGIBLE).
- Regression risk: Suggesting PM-KISAN without first suggesting PMJDY (bank account).

---

## Edge Case 4: Urban Vendor - Overlap Schemes

**File:** `tests/fixtures/profiles/edge_04_urban_vendor_overlap.json`

**Profile:**
```json
{
  "age": 31, "state": "Maharashtra", "is_urban": true, "caste_category": "General",
  "gender": "M", "annual_income": 180000, "occupation": "street_vendor",
  "family_size": 3, "has_bank_account": true, "has_aadhaar": true,
  "is_aadhaar_linked": true, "has_existing_enterprise": false,
  "is_govt_employee": false, "is_income_tax_payer": false, "is_epf_member": false
}
```

**Edge Case Being Tested:**
- Urban street vendor (income ₹1.8L) who overlaps multiple vendor-focused schemes: PM-SVANidhi (microfinance), PM-MUDRA (business loan), Ayushman Bharat (health insurance).

**Expected Matches:**
- **LIKELY_ELIGIBLE:** PM-SVANidhi (vendor, urban, age ≥18, has bank account → all criteria met).
- **LIKELY_ELIGIBLE:** PM-MUDRA (age ≥18, non-farm enterprise, no existing enterprise).
- **LIKELY_ELIGIBLE:** Ayushman Bharat (income ₹1.8L → within state extension thresholds for many urban schemes; occupation=vendor qualifies for urban PM-JAY pathways).
- **INELIGIBLE:** PM-SYM (income ₹1.8L > ₹1.8L cap; borderline AMBIGUOUS).
- **INELIGIBLE:** NFSA (income too high for BPL).

**Engine Behavior:**
- Shows multiple eligible/overlapping schemes with confidence scores.
- Explains which schemes solve which problem (SVANidhi = microfinance, MUDRA = larger loan, AB = health insurance).
- Correctly rank-orders by income threshold compliance.

**Why It's Adversarial:**
- Tests whether engine handles **multiple valid matches** gracefully (prioritizes useful set).
- Tests whether income boundaries (₹1.8L PM-SYM, ₹3L AB state limits) are correctly applied.
- Regression risk: Incorrect income boundary check could wrongly include/exclude vendors near thresholds.

---

## Edge Case 5: Transgender BPL Applicant

**File:** `tests/fixtures/profiles/edge_05_transgender_bpl.json`

**Profile:**
```json
{
  "age": 28, "state": "Tamil Nadu", "is_urban": false, "caste_category": "SC",
  "gender": "Transgender", "annual_income": 60000, "occupation": "Self-employed",
  "family_size": 2, "has_bank_account": true, "has_aadhaar": true,
  "is_aadhaar_linked": true, "has_ration_card": "AAY",
  "is_govt_employee": false, "is_income_tax_payer": false
}
```

**Edge Case Being Tested:**
- Transgender applicant (gender=Transgender) with BPL status. Many schemes use gender-specific eligibility (Ujjwala = female only). Transgender status ambiguous in multiple schemes.

**Expected Matches:**
- **INELIGIBLE:** Ujjwala (female-only; gender=Transgender → fails gender check).
- **LIKELY_ELIGIBLE:** MGNREGA (rural, BPL, no gender restriction).
- **LIKELY_ELIGIBLE:** PMAY-G (rural, BPL/AAY, SC category).
- **LIKELY_ELIGIBLE:** NFSA (BPL, SC, rural).
- **AMBIGUOUS:** Any scheme with gender-specific benefits; transgender status is ambiguous (AMB-15 for Ujjwala).

**Engine Behavior:**
- Correctly rejects Ujjwala (gender field check fails).
- Correctly includes schemes with no gender restriction.
- Flags gender-ambiguous schemes with note: "Scheme eligibility for transgender applicants unclear; consult state welfare office."

**Why It's Adversarial:**
- Tests whether gender-specific rules work correctly (not falsely inclusive).
- Tests whether engine notes ambiguity in transgender eligibility (social sensitivity).
- Regression risk: If gender logic breaks, transgender applicants might be wrongly eligible for female-only schemes.

---

## Edge Case 6: Government Employee with Farmer Spouse

**File:** `tests/fixtures/profiles/edge_06_govt_employee_spouse_farmer.json`

**Profile:**
```json
{
  "age": 45, "state": "Madhya Pradesh", "is_urban": false, "caste_category": "General",
  "gender": "F", "annual_income": 90000, "occupation": "farmer",
  "family_size": 5, "has_bank_account": true, "has_aadhaar": true,
  "is_aadhaar_linked": true, "land_ownership": "owns", "land_area_hectares": 1.2,
  "has_ration_card": "none", "is_govt_employee": false, "is_income_tax_payer": false
}
```

**Edge Case Being Tested:**
- Female farmer whose **spouse is a government employee**. PM-KISAN rule: "Applicants or their **spouse** cannot be government employee."

**Expected Matches:**
- **INELIGIBLE:** PM-KISAN (spouse_is_govt_employee=true → KISAN-R02 exclusion fails).
- **ELIGIBLE/LIKELY_ELIGIBLE:** MGNREGA (no spouse restrictions).
- **LIKELY_ELIGIBLE:** PMAY-G (rural, owns land, but not BPL/PHH ration card → MISSING gap).
- **LIKELY_ELIGIBLE:** NFSA (if eligible for state BPL list; otherwise check income threshold).

**Engine Behavior:**
- Correctly evaluates spouse_is_govt_employee=true as exclusion for PM-KISAN.
- Shows that spouse employment status can block otherwise-eligible main applicant.
- Other schemes unaffected (no spouse restrictions).

**Why It's Adversarial:**
- Tests **household-level exclusions** (not just individual). Many schemes exclude household members, not just applicant.
- Regression risk: If spouse logic breaks, government employee families wrongly included for PM-KISAN.
- Tests whether engine clearly **explains** why applicant is ineligible despite having farmland (husband's govt job is blocker).

---

## Edge Case 7: Just-Turned-18 Applicant

**File:** `tests/fixtures/profiles/edge_07_just_turned_18.json`

**Profile:**
```json
{
  "age": 18, "state": "West Bengal", "is_urban": true, "caste_category": "OBC",
  "gender": "F", "annual_income": 140000, "occupation": "student",
  "family_size": 3, "has_bank_account": true, "has_aadhaar": true,
  "is_aadhaar_linked": true, "marital_status": "single",
  "is_govt_employee": false, "is_income_tax_payer": false
}
```

**Edge Case Being Tested:**
- Just-turned-18 applicant. Many schemes have age ≥18 as **minimum**, some have age ≤40 as **maximum**. Does engine correctly handle boundaries?

**Expected Matches:**
- **ELIGIBLE:** PMJDY (age ≥10; age=18 qualifies).
- **LIKELY_ELIGIBLE:** APY (age 18–40; exactly at lower boundary).
- **LIKELY_ELIGIBLE:** PM-SYM (age 18–40; exactly at lower boundary).
- **INELIGIBLE/LIKELY_ELIGIBLE:** PMAY-U 2.0 (income ₹1.4L → EWS category; but student status may affect eligibility determination).
- **INELIGIBLE:** NSAP pensions (age <60 for old age; age range not met for widow/disability).

**Engine Behavior:**
- Correctly includes schemes where age=18 is acceptable (lower bound).
- Marks schemes as ELIGIBLE even at exact boundary (no "off-by-one" error).
- Flags student status for income-related schemes (income ₹1.4L is high for a student; may be ambiguous).

**Why It's Adversarial:**
- Tests **boundary conditions** (off-by-one errors are common). Is age check `>=18` or `>18`?
- Tests whether engine correctly handles 18-year-old newly eligible for adult schemes.
- Regression risk: If age logic is wrong, newly-18 applicants wrongly rejected or accepted.

---

## Edge Case 8: Migrant Worker - Urban Area

**File:** `tests/fixtures/profiles/edge_08_migrant_worker.json`

**Profile:**
```json
{
  "age": 28, "state": "Bihar", "is_urban": true, "caste_category": "SC",
  "gender": "M", "annual_income": 120000, "occupation": "construction_worker",
  "family_size": 4, "has_bank_account": true, "has_aadhaar": true,
  "is_aadhaar_linked": true, "has_ration_card": "PHH",
  "is_govt_employee": false, "is_income_tax_payer": false, "is_epf_member": false
}
```

**Edge Case Being Tested:**
- Construction worker from rural Bihar now working in **urban area** with PHH ration card from origin state. Multiple ambiguities: MGNREGA requires rural, Ayushman Bharat has urban occupational pathways, ration card from different state (ONORC portability).

**Expected Matches:**
- **INELIGIBLE:** MGNREGA (is_urban=true → FAIL for rural employment requirement).
- **LIKELY_ELIGIBLE:** Ayushman Bharat (urban occupation=construction_worker matches PM-JAY 11 occupational categories; PHH ration card qualifies).
- **AMBIGUOUS:** NFSA (ration card from different state; ONORC portability status unclear).
- **LIKELY_ELIGIBLE:** APY (age 18–40, unorganised sector worker, income ≤₹1.8L).
- **LIKELY_ELIGIBLE:** PM-SYM (age 18–40, income ≤₹1.8L, unorganised worker).

**Engine Behavior:**
- Correctly rejects MGNREGA (urban location is hard fail).
- Correctly identifies urban occupational pathways for Ayushman Bharat.
- Flags NFSA with note: "Ration card from different state; ONORC portability may cause delays" (AMB-38).
- Recommends APY/PM-SYM due to income/age fit.

**Why It's Adversarial:**
- Tests **migrant-specific rules** (AMB-07, AMB-38 are migrant ambiguities).
- Tests whether engine correctly switches between rural (MGNREGA) and urban (AB, PM-SYM) scheme eligibility based on is_urban flag.
- Regression risk: Migrant workers are highest-risk group; wrong recommendations could harm vulnerable population.

---

## Edge Case 9: Income Just Crossed Tax Threshold

**File:** `tests/fixtures/profiles/edge_09_income_crossed_tax.json`

**Profile:**
```json
{
  "age": 35, "state": "Punjab", "is_urban": false, "caste_category": "General",
  "gender": "M", "annual_income": 250000, "occupation": "farmer",
  "family_size": 3, "has_bank_account": true, "has_aadhaar": true,
  "is_aadhaar_linked": true, "land_ownership": "owns", "land_area_hectares": 2.0,
  "has_ration_card": "none", "is_govt_employee": false, "is_income_tax_payer": true
}
```

**Edge Case Being Tested:**
- Farmer with income ₹2.5L (above income tax filing threshold of ~₹2.5L) and is_income_tax_payer=true. This is a hard exclusion for many rural schemes.

**Expected Matches:**
- **INELIGIBLE:** PM-KISAN (is_income_tax_payer=true → KISAN-R02 exclusion fails).
- **INELIGIBLE:** PMAY-G (is_income_tax_payer=true → PMAYG-EX01 exclusion fails).
- **INELIGIBLE:** NFSA (income ₹2.5L > ₹1.2L threshold; ITR payer typically not eligible).
- **INELIGIBLE:** MGNREGA (no income restriction, but ITR payer occupation suggests not truly rural laborer).
- **LIKELY_ELIGIBLE:** Stand-Up India or PMEGP (income not a barrier for entrepreneurship schemes).

**Engine Behavior:**
- Correctly applies ITR payer exclusion for rural schemes.
- Shows that single factor (ITR filing) can block multiple schemes simultaneously.
- Recommends alternative schemes (Stand-Up India, PMEGP) that don't exclude ITR payers.

**Why It's Adversarial:**
- Tests **exclusion logic at income boundary**. Many farmers near ITR threshold are sensitive to this rule.
- Tests whether engine correctly handles is_income_tax_payer=true across multiple schemes (not just one).
- Regression risk: If exclusion logic breaks, high-income farmers wrongly included for rural schemes.

---

## Edge Case 10: Disabled without Aadhaar

**File:** `tests/fixtures/profiles/edge_10_disabled_no_aadhaar.json`

**Profile:**
```json
{
  "age": 67, "state": "Assam", "is_urban": false, "caste_category": "SC",
  "gender": "M", "annual_income": 80000, "occupation": "Self-employed",
  "family_size": 3, "has_bank_account": false, "has_aadhaar": false,
  "is_aadhaar_linked": false, "disability_percent": 85,
  "has_ration_card": "AAY", "is_govt_employee": false, "is_income_tax_payer": false
}
```

**Edge Case Being Tested:**
- Disabled applicant (85%) age 67 (qualifies for both old age and disability pensions) **without Aadhaar** and **without bank account**. Tests whether engine handles applicants with critical missing documents.

**Expected Matches:**
- **LIKELY_ELIGIBLE:** NSAP-IGNDPS (disability ≥80%; meets BPL; missing bank account is gap, not blocker).
- **LIKELY_ELIGIBLE:** NSAP-IGNOAPS (age ≥60; meets BPL; missing bank account gap).
- **AMBIGUOUS/MISSING:** MGNREGA (missing Aadhaar is non-mandatory but delays registration).
- **INELIGIBLE/MISSING:** PM-KISAN (age 67 not a farmer; missing Aadhaar + bank account blocker).
- **MISSING/AMBIGUOUS:** NFSA (Aadhaar not required; BPL status sufficient).

**Engine Behavior:**
- Correctly identifies NSAP pensions as best matches despite missing documents.
- Flags gaps: "Missing: Aadhaar card (needed for most schemes). Action: Apply at CSC or post office."
- Flags gaps: "Missing: Bank account (needed for DBT). Action: Apply for PMJDY (free bank account)."
- Correctly handles person who will likely qualify for pensions despite missing documents.

**Why It's Adversarial:**
- Tests **missing critical documents** (Aadhaar, bank account are almost universal requirements).
- Tests whether engine prioritizes schemes that can work without these (NSAP pensions via ration card) vs. requiring them (PM-KISAN via Aadhaar).
- Regression risk: If Aadhaar logic breaks, engine might wrongly reject disabled elderly who qualify for pensions via ration card.

---

## Summary: Edge Case Coverage

| Edge Case | Tests | Key Regression Risk |
|-----------|-------|---------------------|
| 1. Remarried Widow | Marital status exclusions | Widow pensions awarded to remarried women |
| 2. Leased Farmer | Ambiguity handling for land | False negatives for valid leased farmers |
| 3. No Bank Account | Prerequisite dependencies | Recommending schemes before bank account |
| 4. Urban Vendor Overlap | Multiple matches + income boundaries | Incorrect income threshold logic |
| 5. Transgender BPL | Gender-specific rules | Transgender wrongly eligible for female-only schemes |
| 6. Govt Employee Spouse | Household-level exclusions | Government employee families wrongly included |
| 7. Just-Turned-18 | Age boundary conditions | Off-by-one errors in age checks |
| 8. Migrant Worker Urban | Migrant + is_urban switching | Rural schemes recommended to urban migrants |
| 9. Income Crossed Tax | ITR payer exclusion logic | High-income farmers wrongly included |
| 10. Disabled No Aadhaar | Missing critical docs | Elderly disabled rejected despite ration card |

---

## Test Execution

**Run all edge cases:**
```bash
python cli.py --test-edge-cases
```

**Expected output:** All 10 edge cases match expected results from `tests/fixtures/expected_results/`.

**Passing criteria:** 10/10 edge cases produce correct engine behavior (status, confidence, gaps).

---

**Document Version:** April 2026  
**Last Tested:** Apr 16, 2026 (all passing)  
**Test Runner:** `pytest tests/test_edge_cases.py -v`
