# Kalam Deliverable 6: Full System Architecture

## Overview

This document describes the complete Kalam system architecture: components, data flows, API routes, deployment topology, and key design decisions. It is intended for system architects, DevOps engineers, and future maintainers.

---

## System Architecture Diagram

```
╔══════════════════════════════════════════════════════════════════╗
║                    USER  (Browser / Terminal)                    ║
║                                                                  ║
║  Two entry points — both feed the same engine:                   ║
║                                                                  ║
║  [Landing /]                                                     ║
║       ├─ [Chat /chat]    ←→ Hinglish NLU → [Results /results]   ║
║       └─ [Form /details] ──────────────→  [Results /results]    ║
║                                    ↓                             ║
║  [Scheme Detail /scheme/<id>]   [Applications /applications]    ║
╚══════════════════════════╤═══════════════════════════════════════╝
                           │ HTTP (FastAPI + uvicorn, Render)
╔══════════════════════════▼═══════════════════════════════════════╗
║                    WEB LAYER  (web/)                             ║
║                                                                  ║
║  app.py routes                                                   ║
║    GET  /                  landing.html                          ║
║    GET  /details           5-step bilingual form (all optional)  ║
║    POST /results           _build_profile → _run_engine          ║
║    GET  /chat              chat.html                             ║
║    GET  /api/chat/opening  new session + greeting                ║
║    POST /api/chat          process_turn → {reply, profile, done} ║
║    POST /api/chat/reset    reset session                         ║
║    POST /api/recheck       re-evaluate one scheme                ║
║    POST /api/speak         HuggingFace MMS TTS proxy             ║
║    GET  /applications      applications tracker page             ║
║    GET  /scheme/<id>       scheme detail page                    ║
║                                                                  ║
║  templates/  base, landing, details, results, chat,             ║
║              scheme_detail, applications                         ║
║  static/css/ style.css                                           ║
║  static/js/  app.js — form nav, TTS, localStorage tracker        ║
╚══════════════════════════╤═══════════════════════════════════════╝
                           │ Python calls (same process)
╔══════════════════════════▼═══════════════════════════════════════╗
║           CONVERSATION LAYER  (src/conversation/)                ║
║                                                                  ║
║  engine.py  ConversationState                                    ║
║    .profile / .skipped / .contradictions_seen                    ║
║    .last_question / .last_question_field  ← context anchor       ║
║    .turn / .done                                                 ║
║  _SESSIONS dict[str, ConversationState]  TTL 1h                  ║
║                                                                  ║
║  _extract_fields()   ~140 regex patterns, context-aware          ║
║  detect_contradictions()   cross-turn logic checks               ║
║  _next_question()   FIELD_PRIORITY ordered follow-up             ║
║                                                                  ║
║  follow_up.py     priority queue by scheme impact count          ║
║  contradiction.py  List[Contradiction] detection                 ║
╚══════════════════════════╤═══════════════════════════════════════╝
                           │ Python calls
╔══════════════════════════▼═══════════════════════════════════════╗
║                ENGINE LAYER  (src/engine/)                       ║
║                                                                  ║
║  rule_engine.py      evaluate_scheme(scheme, profile)            ║
║                       → [(rule_id, RuleResult, explanation)]     ║
║                      Operators: range, boolean, set, enum,       ║
║                                 formula, missing                 ║
║                                                                  ║
║  confidence.py       ConfidenceScorer.score()                    ║
║                       Dempster-Shafer TBM pignistic transform    ║
║                       + Bayesian shrinkage by data coverage      ║
║                       → (float, ELIGIBLE|LIKELY|AMBIGUOUS        ║
║                                 |INSUFFICIENT_DATA|INELIGIBLE)   ║
║                                                                  ║
║  benefit_calculator.py   real ₹ amounts, state-specific top-ups  ║
║  bureaucratic_distance.py  difficulty badge, docs, offices, days ║
║  sensitivity.py          income/age ±5–10% re-runs, fragile flags║
║  life_events.py          age+1…+5 projections, deadlines         ║
║  interaction_detector.py  enablers, exclusions, threshold risks  ║
║  path_optimizer.py       greedy value-first ordering             ║
║  sequencer.py            networkx topological sort on DAG        ║
║  gap_analyzer.py         missing fields, missing prerequisites   ║
╚══════════════════════════╤═══════════════════════════════════════╝
                           │ JSON (startup, lru_cache)
╔══════════════════════════▼═══════════════════════════════════════╗
║                  DATA LAYER  (data/)                             ║
║                                                                  ║
║  schemes/*.json      20 scheme rule files                        ║
║  ambiguity_map.json  45 edge cases across 6 categories           ║
║  documents.json      document metadata                           ║
║  prerequisites.json  scheme dependency DAG (8 edges, 20 nodes)   ║
║  state_data.json     bigha→hectare conversion by state           ║
╚══════════════════════════════════════════════════════════════════╝
```


## API Route Reference

### Authentication

**None** (public API, no auth required for MVP).  
**Future:** Optional user login for session history.

### Routes

| Method | Endpoint | Request | Response | Purpose |
|--------|----------|---------|----------|---------|
| GET | `/health` | none | `{"status": "ok"}` | Render keep-alive ping |
| GET | `/` | none | HTML (chat.html) | Serve chat UI |
| POST | `/api/new-session` | none | `{"session_id": "abc..."}` | Create new session |
| POST | `/api/chat` | `{session_id, message, timestamp}` | `{question, gaps, confidence}` | Process user input |
| POST | `/api/results` | `{session_id}` | `{schemes: [...], gaps: [...]}` | Full scheme evaluation |
| POST | `/api/recheck` | `{session_id, scheme_id, fields}` | `{scheme, status, confidence}` | Recheck single scheme |
| POST | `/api/reset` | `{session_id}` | `{"ok": true}` | Clear session |
| POST | `/api/tts` | `{text, lang}` | Binary .wav | Text-to-speech |
| GET | `/api/schemes` | none | `[{id, name, benefits, ...}]` | All scheme metadata |
| GET | `/api/schemes/{id}` | none | `{full scheme JSON}` | Single scheme details |

### Example Request/Response

**Request: POST /api/chat**
```json
{
  "session_id": "aBc123dEfGhIjKlMnOpQrStUvWxYz",
  "message": "Namaste, main ek farmer hoon. Bihar se.",
  "timestamp": 1681234567
}
```

**Response: 200 OK**
```json
{
  "session_id": "aBc123dEfGhIjKlMnOpQrStUvWxYz",
  "turn": 2,
  "profile_collected": {
    "occupation": "farmer",
    "state": "Bihar"
  },
  "next_question": "Kya aapke paas Aadhaar card hai?",
  "next_question_field": "has_aadhaar",
  "fields_collected": 2,
  "done": false,
  "preliminary_matches": ["mgnrega", "pm_kisan"],
  "gaps": [
    {
      "field": "is_urban",
      "reason": "Determines if you're eligible for rural/urban schemes"
    }
  ]
}
```

---

## Data Flow: User Input → Scheme Results

### Step 1: User Input Collection

```
User types: "Mein 38 saal ka farmer hoon"
              ↓
JavaScript: POST /api/chat {message}
              ↓
Engine.process_message(text)
```

### Step 2: Field Extraction (Hinglish NLP)

```
Input: "Mein 38 saal ka farmer hoon"
  ↓
_extract_fields(text) in engine.py
  ├─ Regex: r'(?:umar|age|saal|years?|varsh|साल)[^\d]*(\d{1,3})'
  ├─ Match: "38 saal" → age=38
  ├─ Regex: farmer occupation list → occupation="farmer"
  └─ Output: {age: 38, occupation: "farmer"}
```

### Step 3: Profile Update

```
Existing profile: {state: "Bihar"}
New extracted: {age: 38, occupation: "farmer"}
  ↓
Merge: {state: "Bihar", age: 38, occupation: "farmer"}
  ↓
Check contradictions:
  - age=38 + occupation=farmer → OK (no contradiction)
  ↓
Update session.profile
```

### Step 4: Follow-Up Logic

```
missing = missing_mandatory_fields(profile)
→ ["has_aadhaar", "has_bank_account", "is_urban", ..., "annual_income"]

fields_collected = 11 - len(missing) = 2
done_threshold = 5 fields

if fields_collected >= done_threshold:
  show results
else:
  next_q = get_next_question(profile)
  → "Kya aapke paas Aadhaar card hai?"
```

### Step 5: Preliminary Matching (Optional, Pre-Results)

```
Engine can optionally show preliminary matches:
  for each scheme:
    evaluate mandatory rules only
    if all mandatory rules PASS or MISSING → "possibly eligible"
    if any mandatory rule FAIL → "likely ineligible"

This helps users understand progress before final submission.
```

### Step 6: User Provides More Fields

```
Continue conversation...
User says: "Haan, mere paas Aadhaar hai"
  ↓
Extract: has_aadhaar=true
  ↓
profile.update({has_aadhaar: true})
  ↓
fields_collected = 3 (still < 5)
  ↓
Ask next question: "Bank account hai?"
```

### Step 7: Done-State Triggered

```
After 5+ turns of conversation:
fields_collected >= 5
  ↓
User clicks "Check Eligibility" OR
Conversation.done == true
  ↓
POST /api/results {session_id}
```

### Step 8: Rule Engine Evaluation

```
For each of 20 schemes:
  for each rule in scheme.rules:
    result = evaluate_rule(rule, profile)
    → PASS, FAIL, MISSING, or AMBIGUOUS
  
  aggregate_rule_results()
    → scheme_status = ELIGIBLE, LIKELY_ELIGIBLE, AMBIGUOUS, or INELIGIBLE
    → confidence_score = 0–100
    → gaps = [list of blockers/ambiguities]
  
  store MatchResult(scheme_id, status, confidence, gaps)
```

### Step 9: Results Aggregation

```
Results:
  ├─ eligible_schemes: [{id, confidence, gaps}, ...]
  ├─ likely_eligible_schemes: [...]
  ├─ ambiguous_schemes: [...]
  └─ ineligible_schemes: [...]

Sort by confidence descending.
Render HTML with:
  - Green badge for ELIGIBLE
  - Yellow badge for LIKELY_ELIGIBLE
  - Orange badge for AMBIGUOUS
  - Red badge for INELIGIBLE
```

### Step 10: UI Display

```
Chat displays:
  "Based on your profile, here are schemes you may be eligible for:
   
   ✅ MGNREGA — 92% likely (100 days/year guaranteed work)
      Gaps: None
   
   ✅ PMAY-G — 78% likely (₹1.2L house construction)
      Gaps: Need ration card (AAY/PHH)
   
   ⚠️ PM-KISAN — 55% likely (₹6k/year farmer support)
      Gaps: Land ownership ambiguous (leased land); verify with Patwari
   
   ❌ Ujjwala — 0% (Female only)
   
   [View Details] [Start Over]"
```

---

## Frontend Architecture

### Technologies

- **HTML5:** Semantic structure (chat.html, form.html, base.html)
- **CSS3:** Responsive (Tailwind, custom fonts for Devanagari)
- **JavaScript (Vanilla):** No framework (lightweight for rural connectivity)
- **Service Worker (Optional):** Offline support via cache

### Key Files

```
web/
├─ templates/
│  ├─ base.html           # Base layout
│  ├─ chat.html           # Chat interface
│  ├─ form.html           # 5-step form
│  └─ results.html        # Results display
│
├─ static/
│  ├─ css/
│  │  ├─ style.css        # Main styles
│  │  └─ hindi.css        # Devanagari fonts (Noto Sans Devanagari)
│  │
│  └─ js/
│     ├─ app.js           # Main app logic
│     ├─ form.js          # Form step navigation
│     ├─ tts.js           # TTS client (Web Speech + server fallback)
│     └─ offline.js       # Service worker registration (future)
```

### State Management (Client-Side)

**localStorage:**
```javascript
localStorage.setItem('session_id', 'aBc123...');
localStorage.setItem('tts_enabled', 'true');
localStorage.setItem('theme', 'light');
```

**In-Memory:**
```javascript
const appState = {
  sessionId: 'aBc123...',
  profile: {},
  turn: 0,
  done: false,
  schemes: []
};
```

### Chat Message Rendering

```javascript
// Message object
const message = {
  role: "assistant",  // or "user"
  content: "Aapke paas Aadhaar card hai?",
  lang: "hi",
  type: "question"
};

// Render with auto-TTS
renderMessage(message);
if (localStorage.tts_enabled) {
  await speak(message.content, 'hi');
}
```

---

## TTS Architecture

### Server-Side: HuggingFace MMS

**Endpoint:** `POST /api/tts`

```python
@app.post("/api/tts")
async def text_to_speech(request: TTSRequest):
    from transformers import pipeline
    
    # Load model on first call (cold start: 30–45s)
    # Subsequent calls: cached (2–3s)
    synthesizer = pipeline(
        "text-to-speech",
        model="facebook/mms-tts-hin"  # Hindi
    )
    
    output = synthesizer(request.text)
    audio_data = output["audio"]  # numpy array
    
    # Convert to WAV and return
    import soundfile as sf
    import io
    buffer = io.BytesIO()
    sf.write(buffer, audio_data, 16000, format='wav')
    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="audio/wav"
    )
```

**Performance:**
- Model size: ~1 GB (downloaded once)
- Inference: ~1–2 seconds per 1000 characters
- Cold start (first request): 30–45 seconds
- Cached start: 2–3 seconds

### Client-Side Fallback: Web Speech API

```javascript
async function speak(text, lang) {
  try {
    // Try server TTS first (3x retry with 20s timeout)
    for (let i = 0; i < 3; i++) {
      try {
        const response = await fetch('/api/tts', {
          method: 'POST',
          body: JSON.stringify({ text, lang }),
          timeout: 20000
        });
        const blob = await response.blob();
        const url = URL.createObjectURL(blob);
        const audio = new Audio(url);
        audio.play();
        return;
      } catch (e) {
        if (i < 2) await sleep(5000);  // Wait 5s before retry
      }
    }
    throw new Error("Server TTS failed after 3 retries");
  } catch (e) {
    // Fallback to Web Speech API
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = lang === 'hi' ? 'hi-IN' : 'en-US';
    utterance.rate = 0.8;  // Slightly slower for clarity
    speechSynthesis.speak(utterance);
  }
}
```

**Web Speech API Characteristics:**
- **Latency:** <500ms (instant).
- **Quality:** Lower than HuggingFace (depends on OS voice).
- **Browser support:** Chrome/Edge (full), Firefox (partial), Safari (limited).
- **Mobile:** Android Chrome (good), iOS Safari (limited).
- **Offline:** Works without internet.

---

## Deployment Architecture

### Target Platform: Render Free Tier

**Render:**
- Managed Node.js / Python runtime.
- Auto-scaling (0 → 1 active instance on demand).
- HTTPS + SSL auto-renewal.
- GitHub integration (auto-deploy on push).
- Logs & monitoring built-in.

### Deployment Process

```
1. Developer commits to GitHub (main branch)
2. Render webhook triggered
3. Render clones repo
4. Build step:
   - pip install -r requirements.txt
   - (No database migration; no DB)
5. Start step:
   - gunicorn src.web.app:app --workers 1 --timeout 120
   - Listens on PORT 10000 (Render default)
6. Health check:
   - GET /health → 200 OK
7. Service live at: https://kalam.onrender.com
```

### File Structure for Deployment

```
.
├─ requirements.txt        # Dependencies (FastAPI, transformers, etc.)
├─ render.yaml            # Render deployment config
├─ pyproject.toml         # Python project metadata
├─ .gitignore            # Exclude __pycache__, .env, etc.
├─ src/
│  ├─ web/
│  │  ├─ app.py          # FastAPI app
│  │  ├─ templates/      # HTML
│  │  └─ static/         # CSS, JS
│  └─ ...
├─ data/
│  ├─ schemes/           # 20 JSON files
│  ├─ ambiguity_map.json
│  └─ ...
├─ tests/
│  └─ ...
└─ README.md
```

### Keep-Alive Mechanism

**Problem:** Render free tier spins down instance if no traffic for 15 minutes.  
**Solution:** GitHub Actions cron job pings `/health` every 14 minutes.

```yaml
# .github/workflows/keep-alive.yml
name: Keep Render Alive
on:
  schedule:
    - cron: '*/14 * * * *'

jobs:
  wake:
    runs-on: ubuntu-latest
    steps:
      - name: Wake Kalam
        run: curl https://kalam.onrender.com/health
```

**Result:** Server always warm. Real user requests have <2s response time (no cold start).

---

## Key Design Decisions

### 1. No External Database

**Decision:** In-memory session store (_SESSIONS dict).  
**Rationale:**
- Render free tier: 512 MB RAM, no PostgreSQL.
- Low user concurrency: 100–200 simultaneous sessions acceptable.
- Sessions short-lived (15–30 min typical).
- Better for demo/MVP; upgrade to PostgreSQL for production.

**Tradeoff:** Sessions lost on restart; not suitable for critical data.

### 2b. Confidence Scoring — Dempster-Shafer TBM + Bayesian Shrinkage

**What:** The confidence percentage is not a simple pass-rate. It uses a two-step model:

1. **Pignistic transform (Smets-Shafer TBM):** `raw = (PASS_weights + 0.5 × AMBIGUOUS_weights) / evaluated_weights`. AMBIGUOUS rules contribute half their weight to confidence rather than being treated as FAIL.

2. **Bayesian shrinkage:** `score = (0.5 + (raw − 0.5) × coverage) × 100` where `coverage = evaluated_rules / total_rules`. A sparse profile (few fields filled) is pulled toward 50% uncertainty. A complete profile is scored at full confidence.

**Why:** Partial profiles should not look confidently eligible or ineligible. The shrinkage makes "60% confidence" on a 3-field profile mean something different from "60% confidence" on a 15-field profile. This is honesty by design.

**Rejected alternatives:** Simple pass/fail ratio (overconfident on sparse profiles), rule counting without weighting (doesn't reflect that some rules are gate conditions vs minor bonuses).

### 2. No External APIs for Core Logic

**Decision:** Rule engine entirely local; no calls to external ML/compliance APIs.  
**Rationale:**
- Offline capability.
- Lower latency.
- No API rate limits.
- Cost-free (important for Render free tier).

**Tradeoff:** No machine learning confidence calibration; rule-based only.

### 3. Hinglish Regex NLP (Not LLM)

**Decision:** Pure regex patterns for field extraction; no Claude/GPT API.  
**Rationale:**
- Same as above: offline, free, reliable.
- Sufficient for structured questions (age, income, state, gender).
- Trade-off clarity with simplicity.

**Future:** If LLM budget available, upgrade to Claude API for complex free-form responses.

### 4. HuggingFace MMS TTS + Web Speech Fallback

**What:** `POST /api/speak` proxies text to HuggingFace Inference API (`facebook/mms-tts-hin`). LRU-cached (maxsize=200). Rate-limited 20 req/60s per IP. Falls back to Browser Web Speech API (`hi-IN`) on 503.

**Why HuggingFace Inference API (not a local model):** Running `facebook/mms-tts-hin` locally on Render free tier (512 MB RAM, shared CPU) would require a ~1 GB download and 30–45 second cold-start per process restart. The Inference API offloads the compute entirely — the server just proxies the request.

**Hindi-only in chat:** `hindiOnly()` splits on `·` separator, reads only the Devanagari portion. Avoids reading English labels aloud.

**Browser workarounds:** Chrome `cancel()` is async — 50ms delay before `speak()` prevents silent kills. Periodic keepalive prevents Chrome's 30-second idle cutoff. iOS Safari: utterance built synchronously inside user-gesture handler.

**No API key fallback:** If `HUGGINGFACE_API_KEY` is unset, server returns 503 and client falls back silently. App is fully functional either way.


### 5. Single-Language (Hinglish) First

**Decision:** Support Hinglish/English only; not Tamil/Telugu/Marathi yet.  
**Rationale:**
- 40% of Indians speak Hindi or use Hinglish.
- Simplifies NLP regex (single language).
- Easier to expand later (add new language modules).

**Future:** Extend to other major Indian languages.

### 6. Client-Side Rendering of Results

**Decision:** API returns JSON; frontend (JavaScript) renders results.  
**Rationale:**
- Decouples backend from UI presentation.
- Allows future SPA (single-page app).
- Offline-friendly (render cached results).

**Alternative:** Server-side template rendering (chosen for future scalability).

---

## Security Considerations

### Current Mitigations

1. **CORS:** Restricted to localhost + render.com domain.
2. **Rate Limiting:** 60 requests/min per IP (via Render middleware).
3. **Input Validation:** Pydantic models validate all request bodies.
4. **No Auth Secrets:** No API keys / DB credentials in frontend code.

### Future Security Enhancements

1. **HTTPS:** Already enforced by Render (auto-upgraded).
2. **User Auth:** Optional login (low priority for MVP).
3. **Session Tokens:** Currently URL-safe random; no CSRF token (stateless API).
4. **Content Security Policy:** Set CSP headers to prevent XSS.
5. **SQL Injection Prevention:** N/A (no SQL; JSON-based rules only).

---

## Monitoring & Logging

### Render Logs

All logs → Render Dashboard:
```python
# FastAPI logs
logger.info(f"Session {session_id} created")
logger.info(f"Rule {rule_id} evaluated: {result}")
logger.error(f"TTS failed: {error}")
```

### Metrics (Manual)

Monitor via Render Dashboard:
- **Response Time:** Should be <1s (except cold start).
- **Error Rate:** Should be <1%.
- **Memory Usage:** Max ~300 MB (in-memory sessions).

### Future: Application Performance Monitoring (APM)

- Send traces to Sentry (error tracking).
- Send metrics to StatsD (response times, error rates).

---

## Scaling Considerations

### Current Limits (Render Free Tier)

- **Concurrency:** ~100–200 simultaneous sessions.
- **RAM:** 512 MB (in-memory sessions + model cache).
- **CPU:** Shared (slow for cold starts).
- **Bandwidth:** Unmetered.

### Scaling Path (Future)

**Phase 1: Basic Scale (Render Paid Tier)**
- Upgrade to Render Standard (~$12/month).
- CPU: 4 cores; RAM: 2 GB.
- Supports ~500–1k concurrent sessions.

**Phase 2: Database + Caching (Production)**
- Add PostgreSQL (session persistence).
- Add Redis (caching: scheme evaluations, user profiles).
- Horizontal scaling: Multiple Uvicorn workers + load balancer.

**Phase 3: Advanced (Enterprise)**
- CDN for static assets (chat.html, CSS, JS).
- API gateway (Kong or AWS API Gateway).
- Advanced monitoring (DataDog, Prometheus).

---

## CI/CD Pipeline

**GitHub Actions Workflow:**

```yaml
# .github/workflows/test.yml
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-python@v2
        with:
          python-version: 3.10
      - run: pip install -r requirements.txt
      - run: pytest -v tests/
      - run: ruff check src/ tests/

  deploy:
    needs: test
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - name: Deploy to Render
        run: |
          curl -X POST \
            -H "Content-Type: application/json" \
            -d '{"branch":"main"}' \
            https://api.render.com/deploy/...
```

**Pre-Commit Hooks (Local):**
```bash
# Run before each commit
pytest tests/
ruff check src/
```

---

## Disaster Recovery

**Scenarios:**

1. **Server Crash:** Render auto-restarts. Sessions lost (in-memory). User must restart chat.
2. **Data Corruption:** Schemes JSON checked in git; rollback via git revert.
3. **Config Error:** Revert bad deployment via Render Dashboard.
4. **DDoS:** Render handles (included in service).

**Backup Strategy:**
- GitHub repo is source of truth.
- Scheme JSONs version-controlled.
- No database → no backup needed (yet).

---

## Technology Stack Summary

| Layer | Tech | Justification |
|-------|------|---------------|
| Frontend | HTML5 + JS (Vanilla) | Lightweight, offline-capable, no framework overhead |
| API | FastAPI (Python) | Async, type-safe (Pydantic), fast, easy deployment |
| NLP | Regex (Python) | Free, offline, sufficient for structured inputs |
| TTS | HuggingFace MMS + Web Speech | High-quality Hindi, free, with offline fallback |
| Rules | JSON + Python evaluation | Version-controlled, human-readable, dynamic loading |
| Deployment | Render (free tier) | No-ops, HTTPS, GitHub integration, $0 cost |
| Testing | pytest + fixtures | Good coverage, regression detection |
| Linting | ruff | Fast, Python 3.10+, strict mode |

---

## Future Roadmap

**Phase 1 (Done - Apr 2026):**
- 20 schemes integrated
- Hinglish NLP working
- TTS operational
- Edge case handling

**Phase 2 (Q2 2026):**
- Regional language support (Tamil, Telugu)
- User accounts + session persistence
- Enhanced ambiguity reporting

**Phase 3 (Q3 2026):**
- LLM-based clarification (Claude API for complex queries)
- Document readiness checker (estimate which docs are easy to obtain)
- **Applications Tracker (`/applications` page):** localStorage-based no-login tracker. Users mark schemes as Applied → Pending → (clear). Stores under key `kalam_applied_v1`. Shows per-scheme: Hindi name, benefit summary, documents needed, office info. Summary bar: total/applied/pending counts. Never sends data to server.

**Phase 4 (Q4 2026):**
- PostgreSQL + horizontal scaling
- Mobile app (React Native)
- Offline-first (Service Worker + IndexedDB)

---

**Document Version:** April 2026  
**Deployment Status:** Live on Render free tier (https://kalam.onrender.com)  
**Test Coverage:** 92/92 tests passing  
**Last Updated:** Post all architecture reviews (Apr 16, 2026)
