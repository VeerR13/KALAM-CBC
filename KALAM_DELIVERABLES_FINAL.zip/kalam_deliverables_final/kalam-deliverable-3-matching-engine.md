# Kalam Deliverable 3: Matching Engine Technical Reference

## Overview

This document describes the complete matching pipeline: profile collection → rule evaluation → confidence scoring → gap analysis → results rendering. It is intended for developers, testers, and system architects seeking to understand how Kalam determines scheme eligibility.

---

## System Pipeline Architecture

```
User Input (Chat /chat  OR  Form /details)
    ↓
Hinglish NLP Extractor (src/conversation/engine.py)      ← pure regex, ~140 patterns
    ↓
UserProfile (Pydantic v2, 38 optional fields, unit normalisation)
    ↓
Rule Engine Evaluator (src/engine/rule_engine.py)
    ↓
Per-Rule Results → PASS / FAIL / AMBIGUOUS / INSUFFICIENT_DATA
    ↓
Confidence Scorer (src/engine/confidence.py)             ← TBM pignistic + Bayesian shrinkage
    ↓
Scheme-Level MatchResult (status + float confidence)
    ↓
┌──────────────────────────────────────────────────────┐
│  Parallel post-processing (all run on every profile) │
│                                                      │
│  Benefit Calculator      ← real ₹ amounts            │
│  (benefit_calculator.py)   state-specific top-ups    │
│                                                      │
│  Bureaucratic Distance   ← difficulty badge,         │
│  (bureaucratic_distance.py) docs needed, office,     │
│                             estimated days           │
│                                                      │
│  Sensitivity Analyzer    ← income/age ±5–10%,        │
│  (sensitivity.py)          flags fragile eligibility │
│                                                      │
│  Life Event Projector    ← runs engine at age+1…+5,  │
│  (life_events.py)          surfaces deadlines &      │
│                             opportunities            │
│                                                      │
│  Interaction Detector    ← mutual exclusions,        │
│  (interaction_detector.py) enablers, threshold risks │
│                                                      │
│  Path Optimizer +        ← networkx topological sort │
│  Prerequisite Sequencer    on dependency DAG,        │
│  (path_optimizer.py,       greedy value ordering     │
│   sequencer.py)                                      │
└──────────────────────────────────────────────────────┘
    ↓
Final Results Renderer (Jinja2 templates)
    ↓
UI: confidence bars, benefit amounts, bureaucratic distance badges,
    sensitivity flags, life event warnings, optimal path, 
    scheme interaction notes, Hindi audio on every card
```

---

## Component 1: User Profile Model

**Location:** `src/models/user_profile.py`

**Core Fields:**
```python
class UserProfile:
    # Demographics
    age: int | None
    gender: str | None  # "M", "F", "Transgender"
    state: str | None
    is_urban: bool | None
    family_size: int | None
    marital_status: str | None  # "single", "married", "widowed", "divorced"
    
    # Economic
    annual_income: int | None  # in ₹
    occupation: str | None
    has_bank_account: bool | None
    has_aadhaar: bool | None
    is_aadhaar_linked: bool | None
    
    # Land & Assets
    land_ownership: str | None  # "owns", "leases", "none"
    land_area_hectares: float | None
    has_existing_enterprise: bool | None
    has_motorized_vehicle: bool | None
    has_kisan_credit_card: bool | None
    
    # Social & Health
    caste_category: str | None  # "SC", "ST", "OBC", "General"
    has_ration_card: str | None  # "AAY", "PHH", "none", "unknown"
    disability_percent: int | None
    is_pregnant_or_lactating: bool | None
    
    # Employment
    is_govt_employee: bool | None
    is_income_tax_payer: bool | None
    is_epf_member: bool | None
    
    # Previous Schemes
    previous_scheme_loans: list[str] | None  # ["pmegp", "pm_mudra", ...]
```

**Normalization Functions:**
- `normalize_bigha_to_hectares()`: Convert Indian land units.
- `normalize_gaj_to_hectares()`: Convert square gaj to hectares.
- `normalize_sqft_to_hectares()`: Convert sq. feet.

---

## Component 2: Rule Engine Evaluator

**Location:** `src/engine/rule_engine.py`

**Core Logic:**
```python
def evaluate_rule(rule: Rule, profile: UserProfile) -> RuleResult:
    """
    Evaluates a single eligibility rule against a user profile.
    Returns: PASS, FAIL, MISSING, or AMBIGUOUS
    """
```

### Rule Structure (from JSON)

```json
{
  "rule_id": "KISAN-R01",
  "parameter": "landholding",
  "description": "...",
  "condition": {
    "type": "field_check|boolean_check|range_check|exclusion|composite",
    "field": "land_ownership",
    "values": ["owns"],
    "ambiguous_values": ["leases", "sharecrop"]
  },
  "is_mandatory": true,
  "weight": 20,
  "ambiguity_refs": ["AMB-01"],
  "ambiguity_note": "..."
}
```

### Condition Types

| Type | Logic | Example |
|------|-------|---------|
| **field_check** | Field value matches one of `values` list | `land_ownership in ["owns", "leases"]` |
| **boolean_check** | Field equals true/false | `has_aadhaar == true` |
| **range_check** | Field within `min`/`max` bounds | `age >= 18 and age <= 40` |
| **exclusion** | If any `any_true_fails` condition is true, rule fails | `is_govt_employee == true` → FAIL |
| **composite** | OR/AND across multiple sub_conditions | `(ration_card in AAY/PHH) OR (occupation in vendor list)` |

### RuleResult Enum

```python
class RuleResult(Enum):
    PASS = "pass"        # Rule satisfied; eligibility confirmed
    FAIL = "fail"        # Rule not satisfied; ineligibility confirmed
    MISSING = "missing"  # Required field not in profile
    AMBIGUOUS = "ambig"  # Condition cannot be evaluated; unclear
```

### Evaluation Logic

1. **If field is None:** 
   - If rule is mandatory → MISSING
   - If rule is optional → MISSING (reduces confidence)

2. **If field exists:**
   - Check against `values` list → PASS/FAIL
   - If field in `ambiguous_values` → AMBIGUOUS
   - For range checks: PASS if in range; FAIL if out of range

3. **Exclusion rules:**
   - If any condition in `any_true_fails` is true → FAIL
   - Example: `is_govt_employee=true` → FAIL for PM-KISAN (except Group D per AMB-45)

---

## Component 3: Confidence Scorer

**Location:** `src/engine/confidence.py`

### Match Status Enum

```python
class MatchStatus(Enum):
    ELIGIBLE = "eligible"              # All mandatory rules PASS
    LIKELY_ELIGIBLE = "likely_eligible"  # Most rules PASS; few AMBIGUOUS/MISSING
    AMBIGUOUS = "ambiguous"            # Critical rules AMBIGUOUS; user must verify
    INELIGIBLE = "ineligible"          # ≥1 mandatory rule FAILs
```

### Confidence Score Calculation

The engine uses **Dempster-Shafer TBM (Transferable Belief Model) pignistic transform** combined with **Bayesian shrinkage by data coverage** — not a simple point-deduction model.

**Step 1 — Mandatory gate check:**
Before any numeric scoring, all mandatory rules are checked:
```python
for rule in scheme.rules:
    if rule.is_mandatory:
        if rule_results[rule.rule_id] == RuleResult.FAIL:
            return (0.0, MatchStatus.INELIGIBLE)
```
Any mandatory FAIL → immediately INELIGIBLE at 0% confidence. No further calculation.

**Step 2 — Dempster-Shafer TBM Pignistic Transform:**

Each evaluated rule contributes to a mass assignment. AMBIGUOUS rules split their weight equally between PASS and FAIL:

```
raw_score = (Σ PASS_weights + 0.5 × Σ AMBIGUOUS_weights) / Σ evaluated_weights
```

| Rule result | Contribution |
|-------------|-------------|
| PASS | Full weight added to PASS mass |
| FAIL | Full weight added to FAIL mass (mandatory = gate fail) |
| AMBIGUOUS | Half weight to PASS, half to FAIL |
| INSUFFICIENT_DATA | Excluded from evaluated weight |

**Step 3 — Bayesian shrinkage by data coverage:**

A sparse profile (few fields filled) gets pulled toward 50% uncertainty. A complete profile is scored at full confidence.

```
coverage = evaluated_rules / total_rules
score = (0.5 + (raw_score − 0.5) × coverage) × 100
```

This means "60% confidence" on a 3-field profile represents far more uncertainty than "60% confidence" on a 15-field profile. The score is honest about what it knows.

**Example — Leased Farmer for PM-KISAN:**

| Rule | Result | Weight | PASS contribution |
|------|--------|--------|------------------|
| KISAN-R01 (land) | AMBIGUOUS | 20 | 10.0 |
| KISAN-R02 (exclusion) | PASS | 25 | 25.0 |
| KISAN-R03 (Aadhaar-bank) | PASS | 20 | 20.0 |
| KISAN-R04 (Aadhaar) | PASS | 15 | 15.0 |

```
raw = (25 + 20 + 15 + 10) / (25 + 20 + 15 + 20) = 70/80 = 0.875
coverage = 4/4 = 1.0
score = (0.5 + (0.875 − 0.5) × 1.0) × 100 = 87.5%
```

### Status Determination

| Condition | Status |
|-----------|--------|
| Any mandatory rule FAIL | INELIGIBLE (confidence = 0) |
| All mandatory rules PASS + confidence ≥85% | ELIGIBLE |
| All mandatory rules PASS + confidence 60–84% | LIKELY_ELIGIBLE |
| ≥1 mandatory rule AMBIGUOUS/MISSING | AMBIGUOUS |
| Multiple contradictions detected | AMBIGUOUS |

---

## Component 4: Rule Evaluation Results

**Location:** `src/models/match_result.py`

```python
@dataclass
class RuleEvaluation:
    rule_id: str
    parameter: str
    result: RuleResult  # PASS/FAIL/MISSING/AMBIGUOUS
    explanation: str
    weight: int
    is_mandatory: bool

@dataclass
class MatchResult:
    scheme_id: str
    scheme_name: str
    status: MatchStatus  # ELIGIBLE/LIKELY_ELIGIBLE/AMBIGUOUS/INELIGIBLE
    confidence: float  # 0–100
    rule_evaluations: list[RuleEvaluation]
    prerequisite_scheme_ids: list[str]  # Schemes that must be enrolled first
    gaps: list[GapItem]  # What's blocking/unclear
    benefit_summary: str
    documents_needed: list[RequiredDocument]
```

---

## Component 5: Gap Analysis

**Location:** `src/engine/gap_analyzer.py`

Gap analysis identifies what's blocking or unclear about eligibility:

```python
class GapItem(Enum):
    MISSING_INPUT = "missing_input"          # Required field not in profile
    AMBIGUOUS_CRITERION = "ambiguous_criterion"  # Rule condition unclear
    MISSING_PREREQUISITE = "missing_prerequisite"  # Prerequisite scheme required first
```

### Gap Generation Logic

- **ELIGIBLE/INELIGIBLE results:** No gaps (result clear).
- **LIKELY_ELIGIBLE results:** Gap for each MISSING mandatory field; gap for each optional rule that would improve confidence.
- **AMBIGUOUS results:** Gap for each AMBIGUOUS rule with explanation and recommended action.

**Gap Example:**

```json
{
  "gap_type": "AMBIGUOUS_CRITERION",
  "description": "Land ownership unclear — leased land status ambiguous",
  "action": "Consult Patwari for land record verification in state records"
}
```

---

## Component 6: Contradiction Detection

**Location:** `src/conversation/contradiction.py`

Detects and logs logical inconsistencies in profile to highlight potential data quality issues:

**Contradiction Examples:**
- `is_govt_employee=true` AND `annual_income < ₹1.5L/year` (unlikely)
- `is_income_tax_payer=true` AND `annual_income < ₹2.5L/year` (below ITR threshold)
- `has_motorized_vehicle=true` AND `annual_income < ₹50k/year` (unlikely)
- `is_urban=false` AND `occupation in ["Software Engineer", "Data Analyst"]` (unlikely in rural areas)

**Engine Handling:**
- Logs contradictions in `ConversationState.contradictions_seen`.
- Triggers follow-up question: "Earlier you said X, but now I heard Y. Could you clarify?"
- Reduces confidence score slightly (≤5%) but does not trigger FAIL.

---

## Component 7: Bureaucratic Distance Formula

**Location:** Not in current codebase; planned for future release**

The "bureaucratic distance" metric (conceptual) measures how far a user profile is from ideal eligibility:

```
Bureaucratic Distance = Σ(gap_weight × gap_severity) / Total Possible Distance

gap_weight: Number of users impacted by this gap
gap_severity: How much the gap blocks eligibility (0–1 scale)
  - FAIL: severity = 1.0 (complete block)
  - AMBIGUOUS: severity = 0.7 (major uncertainty)
  - MISSING: severity = 0.5 (incomplete info)
  - PASS: severity = 0.0 (no gap)
```

**Interpretation:**
- Distance 0.0 = Perfect eligibility
- Distance 0.1–0.3 = Minor gaps (1–2 ambiguous fields)
- Distance 0.3–0.6 = Moderate gaps (multiple missing/ambiguous)
- Distance 0.6–1.0 = Major gaps (will need manual review)

---

## Component 8: Benefit Calculator

**Location:** `src/engine/benefit_calculator.py` (emerging)

The benefit calculator extracts and formats scheme benefits:

```python
def extract_benefits(scheme: Scheme) -> BenefitSummary:
    """
    Returns:
    {
        "summary": "₹6,000/year in 3 installments",
        "details": {
            "amount": 6000,
            "currency": "INR",
            "frequency": "yearly",
            "installments": 3,
            "terms": "Must remain landholding, Aadhaar-linked bank account"
        },
        "documents_required": [...],
        "application_offices": [...]
    }
```

---

## Component 9: Hinglish NLP Extractor

**Location:** `src/conversation/engine.py` (_extract_fields function)

The engine parses natural language input to extract profile fields using regex patterns without external APIs.

### Supported Patterns by Field

**Age:** 
- "meri umar 35 hai", "35 saal", "age 35", "35 years old"
- Regex: `(?:umar|age|saal|years?)[^\d]*(\d{1,3})`

**Income:**
- "3 lakh", "80 hazar", "1.5 lakh", "₹2,50,000"
- Regex: `(\d+(?:\.\d+)?)\s*(?:lakh|lakhs?|हजार)` → multiplies by 100,000

**Family Size:**
- "4 log ghar mein", "5 member family"
- Regex: `(\d+)\s*(?:log|member|pariwar|family)`

**Gender:**
- "main ek mahila hoon", "I'm a woman", "female"
- Regex: `(?:aurat|mahila|lady|woman)` → "F"

**State:**
- "Bihar", "UP", "मध्य प्रदेश"
- STATE_MAP: 28 state patterns (Hindi + English)

**Urban/Rural:**
- "gaon mein", "village", "city", "shehar"
- Regex: `(?:gaon|village|gram)` → is_urban=false

**Land Ownership:**
- "mere paas zarmin hai", "leased land", "owned property"
- Values: "owns", "leases", "sharecrop", "none"

**Occupation:**
- "farmer", "construction worker", "street vendor"
- Free-form text; normalized against occupation enum

### Context-Aware Extraction

If `last_question_field` is set, extractor looks for related keywords in response:

```python
# If last_question was about income:
if last_question and re.search(r'income|amdani|saalana', last_question):
    # Look for plain numbers that might be income
    nums = re.findall(r'\b(\d{4,8})\b', t)
    if nums:
        extracted["annual_income"] = int(nums[0])
```

---


## Component 10: Sensitivity Analyzer

**Location:** `src/engine/sensitivity.py`

Varies `annual_income` ±5–10% and `age` ±1–3 years, re-runs the full rule engine with modified profile copies, and compares MatchStatus outputs. Surfaces changes as UI flags.

**Example output:** "If your annual income were ₹5,000 lower you would qualify for Ujjwala." This prevents false confidence in borderline cases and flags both opportunities (just above a threshold) and risks (just below one).

**Key design constraint:** This is live computation — not pre-written warnings. The modified profile copies go through the same rule engine as the real profile.

---

## Component 11: Life Event Projector

**Location:** `src/engine/life_events.py`

Creates `profile.copy(age=profile.age + N)` for N = 1, 2, 3, 4, 5 and re-runs the engine for each. Compares eligibility transitions:

- INELIGIBLE → ELIGIBLE = **opportunity** (e.g. NSAP-IGNOAPS opens at 60)
- ELIGIBLE → INELIGIBLE = **deadline** (e.g. APY closes at 40, Sukanya must open before daughter turns 10)

Output shown in the "Important choices & coming up" section of results.

---

## Component 12: Interaction Detector

**Location:** `src/engine/interaction_detector.py`

Analyses the full set of eligible schemes together and flags:

- **Enablers:** PMJDY bank account is prerequisite for 8 other schemes (DBT requirement) → "Apply for PMJDY first"
- **Mutual exclusions:** NSAP-IGNDPS + NSAP-IGNWPS cannot both be held by one person (existing-pension rule)
- **Threshold risks:** Income within 10% of a scheme's cut-off → flag as fragile

---

## Component 13: Path Optimizer + Prerequisite Sequencer

**Location:** `src/engine/path_optimizer.py`, `src/engine/sequencer.py`

Builds a directed acyclic graph from `data/prerequisites.json` using `networkx.DiGraph`. Runs `topological_sort` to establish a valid application order. Within each topological tier, schemes are ordered greedily by annual benefit value (highest first).

Output: numbered step list with Hindi scheme name, reason for ordering, office to visit, and estimated processing days.

---

## Edge Cases Handled

### 1. Missing vs AMBIGUOUS vs UNKNOWN

- **Missing:** Field not provided; user hasn't answered question.
- **AMBIGUOUS:** Field provided but value is uncertain (e.g., leased land for PM-KISAN).
- **Unknown:** User answered "don't know" or "pata nahi".

**Engine Behavior:**
- Missing mandatory field → asks follow-up question (field_priority order).
- AMBIGUOUS rule → shows gap with explanation; user advised to verify locally.
- "Don't know" response → flags field as skipped; reduces confidence by 10% if critical.

### 2. Income Boundary Cases

Income thresholds often have ±20% ambiguity zones:

- PM-SYM: ₹1,80,000/year cut-off. Applicants claiming ₹1,60k–₹2,00k → AMBIGUOUS.
- Ayushman Bharat: ₹3L cut-off. Applicants in ₹2.4L–₹3.6L range → AMBIGUOUS.

### 3. Loan History Edge Cases

- Applicant with fully repaid PM-MUDRA loan from 2 years ago: Still disqualifies for PM Vishwakarma (per AMB-41).
- Engine flags as AMBIGUOUS with note: "Repaid loans may still disqualify; verify with district PM Vishwakarma office."

### 4. Government Employee Exception (PM-KISAN)

- Applicant claims is_govt_employee=true → Engine returns FAIL.
- But note added: "Exception: Class IV/Group D employees (peons, sweepers, gardeners) ARE eligible despite this result. Self-verify at pmkisan.gov.in."

---

## End-to-End Example: Leased Farmer Profile

**Input:** User says: "Mera naam Rajesh hai, main 38 saal, Bihar mein rehta hoon, farmer hoon, zameen kiraye ki hai, 0.66 hectare"

**Extraction (engine.py):**
```python
profile = {
    "age": 38,
    "state": "Bihar",
    "is_urban": False,
    "occupation": "farmer",
    "land_ownership": "leases",
    "land_area_hectares": 0.66
}
```

**Rule Evaluation (rule_engine.py):**

For **PM-KISAN**:
- KISAN-R01 (land ownership): value="leases" → in ambiguous_values → **AMBIGUOUS**
- KISAN-R02 (exclusion): no is_govt_employee/is_income_tax_payer → **PASS**
- KISAN-R03 (aadhaar_linked): missing field → **MISSING**
- KISAN-R04 (aadhaar): missing field → **MISSING**

**Confidence Scoring (confidence.py):**
```
base_score = 100
  - AMBIGUOUS rule: -20 (land ownership unclear)
  - MISSING mandatory rule: -15 (aadhaar_linked)
  - MISSING mandatory rule: -15 (aadhaar)
base_score = 50

Status: AMBIGUOUS (because mandatory rule AMBIGUOUS)
Confidence: 50%
```

**Gap Analysis (gap_analyzer.py):**
```json
[
  {
    "gap_type": "AMBIGUOUS_CRITERION",
    "description": "Land ownership: leased land status ambiguous for PM-KISAN",
    "action": "Consult Patwari to verify if lease/sharecrop land qualifies in Bihar"
  },
  {
    "gap_type": "MISSING_INPUT",
    "description": "Aadhaar linked to bank account not provided",
    "action": "Link Aadhaar to your bank account for PM-KISAN eligibility"
  }
]
```

**Final Result (JSON):**
```json
{
  "scheme_id": "pm_kisan",
  "status": "ambiguous",
  "confidence": 50,
  "gaps": [...],
  "next_question": "Kya aapka Aadhaar bank account se linked hai?"
}
```

---

## Performance Characteristics

| Metric | Value |
|--------|-------|
| Rule Evaluation Time (per rule) | <1ms |
| Full Pipeline (profile → results) | 10–50ms |
| Memory per Session | ~50 KB |
| Concurrent Sessions (Render free tier) | 100–200 |
| Rules per Scheme | 3–8 (avg 5) |
| Total Rules Evaluated | ~100 per profile |

---

## Testing Strategy

**Location:** `tests/` directory

### Test Categories

1. **Unit Tests:** Individual rule evaluators
   - `test_rule_engine.py`: Each rule type tested in isolation
   - Edge cases: missing fields, boundary values, ambiguous inputs

2. **Integration Tests:** Full pipeline
   - `test_end_to_end.py`: Profile → engine → results
   - 10 edge case profiles (`tests/fixtures/profiles/edge_*.json`)

3. **Fixture Tests:** Against expected results
   - `tests/fixtures/expected_results/`: Pre-computed results for 50+ test cases
   - Regression detection if rule logic changes

**Test Command:**
```bash
pytest -v tests/
# Expected: 92/92 tests pass
```

---

## Future Enhancements

1. **Machine Learning Confidence:** Train model on user outcomes to calibrate scores.
2. **Multi-Language Support:** Beyond Hinglish (Tamil, Telugu, Marathi, etc.).
3. **Real-Time Rule Updates:** Rules hot-reloadable from config without code deploy.
4. **Benefit Calculator:** Estimate actual rupee amount (e.g., "You're likely to receive ₹6,000/year from PM-KISAN").
5. **Document Readiness Checker:** Given profile, estimate which required documents can be obtained quickly.

---

**Document Version:** April 2026  
**Last Updated:** After all rule engine fixes (Apr 16, 2026)  
**Tested:** 92/92 test suite passing
