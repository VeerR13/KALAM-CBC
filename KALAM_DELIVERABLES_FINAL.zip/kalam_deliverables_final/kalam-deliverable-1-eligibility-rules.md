# Kalam Deliverable 1: Eligibility Rules Catalogue

## Overview

This document comprehensively catalogs all 20 government schemes integrated into Kalam, including their mandatory eligibility rules, optional/bonus criteria, data freshness status, and confidence weight structure. The rules are sourced from official government PDFs and updated as of April 2026.

---

## Scheme Registry

### 1. PM-KISAN (Pradhan Mantri Kisan Samman Nidhi)
**Scheme ID:** `pm_kisan`  
**Hindi Name:** प्रधानमंत्री किसान सम्मान निधि  
**Ministry:** Ministry of Agriculture & Farmers Welfare  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pmkisan.gov.in

**Mandatory Rules:**
- **Land Ownership** (weight: 20): Applicant must own cultivable land as per state land records. Leased/sharecropped land is ambiguous (AMB-01).
- **Exclusion Check** (weight: 25): Excludes government employees, income tax payers, and their spouses. **Exception:** Class IV/Group D govt workers (peons, gardeners) ARE eligible (AMB-45).
- **Aadhaar-Linked Bank** (weight: 20): Bank account must be seeded with Aadhaar for DBT transfer.
- **Aadhaar** (weight: 15): Applicant must have Aadhaar card.

**Optional Criteria:** None specified.

**Confidence Weights:** Mandatory total: 80 points. FAIL if any mandatory rule fails.

---

### 2. PMAY-G (Pradhan Mantri Awas Yojana – Gramin)
**Scheme ID:** `pmay_g`  
**Hindi Name:** प्रधानमंत्री आवास योजना - ग्रामीण  
**Ministry:** Ministry of Rural Development  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-12  
**Portal:** https://pmayg.nic.in

**Mandatory Rules:**
- **Rural Location** (weight: 20): Applicant must reside in a rural area.
- **SECC/BPL Status** (weight: 25): Must hold AAY or PHH ration card. SECC 2011 data is stale (AMB-04).
- **Aadhaar-Linked Bank** (weight: 15): Bank account seeded with Aadhaar for DBT.

**Optional Criteria:**
- **Housing Need** (weight: 25): Must own or lease land. Landless households may qualify if allotted land by gram panchayat (AMB-11).
- **Exclusion: Wealth** (weight: 20): Excludes govt employees, income tax payers, motorized vehicle owners, KCC ≥₹50k, refrigerator owners, pucca house owners.
- **Exclusion: Income** (weight: 5): Monthly income >₹10,000 (annual >₹1.2L) is exclusion.
- **Exclusion: Land** (weight: 5): Owning ≥7.5 acres (3.035 hectares) is excluded.

**Confidence Weights:** Mandatory total: 60 points. Optional: 55 points max.

---

### 3. MGNREGA (Mahatma Gandhi National Rural Employment Guarantee Act)
**Scheme ID:** `mgnrega`  
**Hindi Name:** महात्मा गांधी राष्ट्रीय ग्रामीण रोजगार गारंटी अधिनियम  
**Ministry:** Ministry of Rural Development  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://nrega.nic.in

**Mandatory Rules:**
- **Age** (weight: 25): Must be ≥18 years old.
- **Rural Residence** (weight: 30): Must live in rural area. Census towns notified under panchayat are ambiguous (AMB-06).
- **Aadhaar** (weight: 20, non-mandatory): Aadhaar used for job card registration. Migrants may have ambiguous panchayat registration (AMB-07).

**Optional Criteria:** None. Universal rural entitlement for all adults willing to do unskilled manual work. No occupation, income, or education restrictions.

**Confidence Weights:** Mandatory: 55 points. No exclusions or optional criteria.

---

### 4. Ayushman Bharat (PM-JAY)
**Scheme ID:** `ayushman_bharat`  
**Hindi Name:** आयुष्मान भारत  
**Ministry:** National Health Authority, Ministry of Health and Family Welfare  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-12  
**Portal:** https://pmjay.gov.in

**Mandatory Rules:**
- **SECC/BPL or Occupation** (weight: 30): Eligible via (1) AAY/PHH ration card OR (2) urban occupation in 11 PM-JAY categories (daily wage worker, vendor, artisan, domestic worker, ragpicker, driver, washerman, rickshaw puller, etc.). State extensions vary (AMB-05).
- **Aadhaar** (weight: 25): Must have Aadhaar. Informal urban workers may lack documentation (AMB-08).

**Optional Criteria:**
- **Income Proxy** (weight: 15): Annual income <₹3L (urban extensions vary by state).

**Confidence Weights:** Mandatory: 55 points. Optional: 15 points.

---

### 5. PMJDY (Pradhan Mantri Jan Dhan Yojana)
**Scheme ID:** `pmjdy`  
**Hindi Name:** प्रधानमंत्री जन-धन योजना  
**Ministry:** Department of Financial Services, Ministry of Finance  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pmjdy.gov.in

**Mandatory Rules:**
- **Age** (weight: 30): Must be ≥10 years old.
- **Identity** (weight: 40): Aadhaar required; any govt ID acceptable. Small accounts allowed with self-declaration if no ID. Duplicate PMJDY accounts may exist from initial drive (AMB-14).

**Optional Criteria:** None. Universal coverage for all Indians aged 10+.

**Confidence Weights:** Mandatory: 70 points.

---

### 6. PM-SYM (Pradhan Mantri Shram Yogi Maan-dhan)
**Scheme ID:** `pm_sym`  
**Hindi Name:** प्रधानमंत्री श्रम योगी मान-धन  
**Ministry:** Ministry of Labour and Employment  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pmsym.gov.in

**Mandatory Rules:**
- **Age** (weight: 25): Must be 18–40 years old.
- **Income** (weight: 25): Monthly income ≤₹15,000 (annual ≤₹1,80,000). Income verification difficult for informal workers (AMB-25).
- **Occupation** (weight: 25): Must be unorganised sector worker (construction, transport, agriculture, domestic work, etc.).

**Optional Criteria:** None.

**Confidence Weights:** Mandatory: 75 points.

---

### 7. PM-SVANidhi (PM Street Vendor's AtmaNirbhar Nidhi)
**Scheme ID:** `pm_svanidhi`  
**Hindi Name:** प्रधानमंत्री स्ट्रीट वेंडर की आत्मनिर्भर निधि  
**Ministry:** Ministry of Housing and Urban Affairs  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pmsvanidhi.mohua.gov.in

**Mandatory Rules:**
- **Street Vendor Occupation** (weight: 35): Must be street vendor, hawker, cobbler, ragpicker, or food vendor. Can have Certificate of Vending, survey identification, or Letter of Recommendation from ULB. Vendor without docs needs LoR (AMB-26). No March 2020 cut-off date (AMB-27 resolved).

**Optional Criteria:**
- **Urban Location** (weight: 20): Preferably urban area.

**Confidence Weights:** Mandatory: 35 points. Optional: 20 points.

---

### 8. PM-MUDRA (Pradhan Mantri MUDRA Yojana)
**Scheme ID:** `pm_mudra`  
**Hindi Name:** प्रधानमंत्री मुद्रा योजना  
**Ministry:** Ministry of Finance (Department of Financial Services)  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://mudra.org.in

**Mandatory Rules:**
- **Age** (weight: 20): Must be ≥18 years old.
- **Non-Farm Enterprise** (weight: 35): Must have or intend to start non-farm micro enterprise. Core crop farming excluded; allied activities (poultry, dairy, beekeeping) qualify (AMB-28).
- **No Existing Enterprise Under Subsidy** (weight: 30): Cannot have existing enterprise under other govt subsidy scheme.

**Optional Criteria:** None specified.

**Confidence Weights:** Mandatory: 85 points.

---

### 9. Stand-Up India
**Scheme ID:** `stand_up_india`  
**Hindi Name:** स्टैंड-अप इंडिया  
**Ministry:** Ministry of Finance, facilitated by SIDBI  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://standupmitra.in

**Mandatory Rules:**
- **SC/ST or Woman** (weight: 35): Applicant must be SC/ST OR woman (male applicants must be SC/ST). For companies: 51%+ held by SC/ST or woman (AMB-32).
- **New Enterprise Only** (weight: 30): Greenfield enterprise only. Closed enterprise is ambiguous (AMB-31).

**Optional Criteria:**
- **No Prior Scheme Loans** (weight: 25): No existing loans under PMEGP/PMMY/other govt schemes.

**Confidence Weights:** Mandatory: 65 points. Optional: 25 points.

---

### 10. NFSA (National Food Security Act 2013 – Ration Card)
**Scheme ID:** `nfsa`  
**Hindi Name:** राष्ट्रीय खाद्य सुरक्षा अधिनियम  
**Ministry:** Department of Food and Public Distribution  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pds.gov.in

**Mandatory Rules:**
- **State BPL Status** (weight: 30): Entirely state-specific. AAY (poorest of poor) vs PHH (remaining population) determined by state criteria (AMB-36, AMB-37). Central rule: income <₹1.2L/year proxy.
- **Vulnerable Category** (weight: 20): SC/ST, widow, disabled, or not a govt employee.

**Optional Criteria:**
- **Income Proxy** (weight: 25): Annual income <₹1.2L.

**Confidence Weights:** Mandatory: 50 points. Optional: 25 points. Highly ambiguous due to state variation.

---

### 11. PM Vishwakarma
**Scheme ID:** `pm_vishwakarma`  
**Hindi Name:** प्रधानमंत्री विश्वकर्मा  
**Ministry:** Ministry of Micro, Small and Medium Enterprises  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pmvishwakarma.gov.in

**Mandatory Rules:**
- **Traditional Trade** (weight: 35): Must be engaged in one of 18 identified traditional trades (carpenter, goldsmith, mason, blacksmith, potter, cobbler, basket maker, etc.) in unorganised sector on self-employment basis (AMB-40).
- **No Recent Credit Scheme** (weight: 30): Cannot have availed PMEGP/PM-SVANidhi/PM-MUDRA recently. Fully repaid loans still disqualify (AMB-41).

**Optional Criteria:**
- **Gram Panchayat/ULB Verification** (weight: 15): Registration requires local verification (AMB-42).

**Confidence Weights:** Mandatory: 65 points. Optional: 15 points.

---

### 12. PMEGP (Prime Minister's Employment Generation Programme)
**Scheme ID:** `pmegp`  
**Hindi Name:** प्रधानमंत्री रोजगार सृजन कार्यक्रम  
**Ministry:** Ministry of Micro, Small and Medium Enterprises  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pmegp.gov.in

**Mandatory Rules:**
- **Age** (weight: 20): Must be ≥18 years old.
- **New Enterprise Only** (weight: 30): Only new micro enterprise projects eligible. Existing units and units under PMRY/REGP/other govt subsidy NOT eligible.
- **Not Government Employee** (weight: 25): Cannot be govt employee or professional.

**Optional Criteria:**
- **Bank Skills Discretion** (weight: 15): Bank may require skills/experience for proposed activity (AMB-29).

**Confidence Weights:** Mandatory: 75 points. Optional: 15 points.

---

### 13. APY (Atal Pension Yojana)
**Scheme ID:** `apy`  
**Hindi Name:** अटल पेंशन योजना  
**Ministry:** Ministry of Labour and Employment (PFRDA)  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://www.apy.nic.in

**Mandatory Rules:**
- **Age** (weight: 25): Must be 18–40 years old.
- **Not EPF Member** (weight: 25): Cannot be existing EPF member. Informal workers with prior formal history may have stale EPF status (AMB-24).

**Optional Criteria:**
- **Regular Contribution** (weight: 20): Must contribute regularly (contribution amount varies by age and desired pension).

**Confidence Weights:** Mandatory: 50 points. Optional: 20 points.

---

### 14. Sukanya Samriddhi Yojana
**Scheme ID:** `sukanya_samriddhi`  
**Hindi Name:** सुकन्या समृद्धि योजना  
**Ministry:** Department of Financial Services, Ministry of Finance  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://www.indiapost.gov.in

**Mandatory Rules:**
- **Girl Child Age** (weight: 35): Must be girl child aged <10 years at opening.
- **Parents/Guardians** (weight: 30): Account opened by parents or legal guardians. Maximum 2 accounts per family.

**Optional Criteria:**
- **Blended Family Limit** (weight: 15): Blended families (step-children, adopted) may face limit issues (AMB-33).

**Confidence Weights:** Mandatory: 65 points. Optional: 15 points.

---

### 15. Ujjwala 2.0 (Pradhan Mantri Ujjwala Yojana)
**Scheme ID:** `ujjwala`  
**Hindi Name:** प्रधानमंत्री उज्ज्वला योजना  
**Ministry:** Ministry of Petroleum and Natural Gas  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pmuy.gov.in

**Mandatory Rules:**
- **Female Applicant** (weight: 25): Must be woman aged 18+. Transgender status is ambiguous (AMB-15).
- **Age** (weight: 20): Must be ≥18 years old.
- **Poor Household** (weight: 25): BPL ration card (AAY/PHH) OR low income as proxy. Self-declaration sufficient for migrants (AMB-15, AMB-16).
- **No Existing LPG** (weight: 20): Household must not have existing LPG connection. Migrant household definition ambiguous (AMB-16).

**Confidence Weights:** Mandatory: 90 points.

---

### 16. PMMVY (Pradhan Mantri Matritva Vandana Yojana)
**Scheme ID:** `pmmvy`  
**Hindi Name:** प्रधानमंत्री मातृत्व वंदना योजना  
**Ministry:** Ministry of Women and Child Development  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://pmmvy.nic.in

**Mandatory Rules:**
- **Pregnant or Lactating Woman** (weight: 30): Must be pregnant or lactating woman aged 19+.
- **First/Second Child** (weight: 30): Eligibility varies: first child ₹5,000; second child (if girl) ₹6,000. Miscarriage/stillbirth treated as fresh case (AMB-34 resolved).
- **Completed Pregnancy Registration** (weight: 25): Pregnancy must be registered with health centre.

**Optional Criteria:**
- **Multiple Births** (weight: 10): Twins/triplets with girls may qualify for second child incentive (AMB-35).

**Confidence Weights:** Mandatory: 85 points. Optional: 10 points.

---

### 17. NSAP-IGNOAPS (Old Age Pension)
**Scheme ID:** `nsap_ignoaps`  
**Hindi Name:** राष्ट्रीय सामाजिक सहायता कार्यक्रम - वरिष्ठ नागरिक पेंशन  
**Ministry:** Ministry of Rural Development  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://nsap.nic.in

**Mandatory Rules:**
- **Age** (weight: 30): Must be ≥60 years old.
- **BPL/State List** (weight: 30): Must be on state BPL list or have AAY/PHH ration card. State lists vary (AMB-17).
- **No Other Pension** (weight: 20): Cannot receive other govt pension. Family support does not count (AMB-44 clarified).

**Optional Criteria:**
- **Rural Residence** (weight: 10): Preference for rural areas; some states extend to urban.

**Confidence Weights:** Mandatory: 80 points. Optional: 10 points. State top-up varies (AMB-18).

---

### 18. NSAP-IGNWPS (Widow Pension)
**Scheme ID:** `nsap_ignwps`  
**Hindi Name:** राष्ट्रीय सामाजिक सहायता कार्यक्रम - विधवा पेंशन  
**Ministry:** Ministry of Rural Development  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://nsap.nic.in

**Mandatory Rules:**
- **Age** (weight: 25): Must be 40–79 years old. Some states have different entry points (AMB-21).
- **Widow Status** (weight: 35): Must be widow (husband deceased). **Remarriage revokes pension** (AMB-20 resolved).
- **BPL/State List** (weight: 20): Must be on state BPL list or have AAY/PHH ration card.

**Optional Criteria:** None.

**Confidence Weights:** Mandatory: 80 points.

---

### 19. NSAP-IGNDPS (Disability Pension)
**Scheme ID:** `nsap_igndps`  
**Hindi Name:** राष्ट्रीय सामाजिक सहायता कार्यक्रम - विकलांगता पेंशन  
**Ministry:** Ministry of Rural Development  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-11  
**Portal:** https://nsap.nic.in

**Mandatory Rules:**
- **Disability Level** (weight: 35): Must have ≥80% disability. 40–79% excluded from central scheme but states may offer separate coverage (AMB-22).
- **Age** (weight: 20): Must be ≥18 years old.
- **BPL/State List** (weight: 25): Must be on state BPL list or have AAY/PHH ration card.

**Optional Criteria:**
- **Dual Eligibility** (weight: 10): Disabled widow may qualify for both IGNDPS and IGNWPS; no clear central guideline (AMB-23).

**Confidence Weights:** Mandatory: 80 points. Optional: 10 points.

---


### PMAY-U (Pradhan Mantri Awas Yojana – Urban)
**Scheme ID:** `pmay_u`  
**Hindi Name:** प्रधानमंत्री आवास योजना - शहरी  
**Ministry:** Ministry of Housing and Urban Affairs  
**Data Freshness:** VERIFIED_AGAINST_PDF_2026-04-12 (September 2024 guidelines)  
**Portal:** https://pmay-urban.gov.in

**Mandatory Rules:**
- **Urban Location** (weight: 20): Must reside in a statutory urban area or notified planning area.
- **Income Tier** (weight: 30): Annual household income within brackets — EWS ≤₹3L / LIG ₹3–6L / MIG ₹6–9L. MIG-II (₹12–18L) category was removed in September 2024 revision. State-level EWS thresholds may vary with MoHUA concurrence (AMB-43).
- **No Pucca House** (weight: 30): Must not own a pucca house anywhere in India (in own name or any family member's name). Cross-state verification is self-declared only (AMB-10).
- **Aadhaar** (weight: 15): All beneficiaries including family members must have Aadhaar/Virtual ID.

**Optional Criteria:**
- **No Prior Housing Benefit** (weight: 25): Must not have been allotted any housing scheme benefit from Central/State/UT/Local Self Government in the past 20 years (urban or rural).

**Key Note:** House must be in the female head's name, or joint with spouse. Male-only ownership only if no adult female family member exists.

**Confidence Weights:** Mandatory total: 95 points. Optional: 25 points.

---

### 20. PMAY-U (listed above as scheme 5 in live system — inserted here for completeness)

*(See above entry.)*

**Total Schemes in Live System:** 20 unique schemes.

**Total Schemes:** 20 unique schemes.

---

## Confidence Scoring Structure

### Mandatory vs Optional Weights

| Status | Definition | Engine Behavior |
|--------|-----------|-----------------|
| **PASS** | All mandatory rules pass; sufficient coverage | Result: ELIGIBLE |
| **FAIL** | ≥1 mandatory rule fails; clear ineligibility | Result: INELIGIBLE |
| **MISSING** | Required field not in profile | Reduces confidence; may ask follow-up |
| **AMBIGUOUS** | Rule condition cannot be clearly evaluated | Flags gap; user advised to verify locally |
| **PARTIAL** | Some rules ambiguous/missing; some pass | Result: LIKELY_ELIGIBLE or AMBIGUOUS |

### Weight Calculation

1. Sum mandatory rule weights: If all PASS → base score is 100.
2. If any mandatory rule FAILS → status = INELIGIBLE (confidence = 0).
3. If mandatory rules are MISSING/AMBIGUOUS → reduce base confidence by 15–25% per ambiguity.
4. Optional rule weights (0–25% bonus) added if all mandatory rules pass.

---

## Data Freshness Status Legend

- **VERIFIED_AGAINST_PDF_YYYY-MM-DD**: Scheme rules verified against official government PDF on the specified date.
- **PENDING_HUMAN_VERIFICATION**: Rules drafted but not yet verified against official PDF. Human drops PDF in `data/pdfs/` and updates this field.

---

## Key Dependencies

### Prerequisite Schemes

- **PM-KISAN** requires: PMJDY (bank account).
- **PMAY-G** requires: PMJDY (bank account).
- Other schemes vary; check individual `prerequisites` array in JSON.

### Related Schemes (Not Prerequisites)

- **NFSA** (ration card) used as proxy for BPL in Ayushman Bharat, PMAY-G, Ujjwala, NSAP schemes.
- **PMJDY** (bank account) prerequisite for DBT-based schemes (PM-KISAN, PMAY-G, MGNREGA, etc.).

---

## Queries and Clarifications

For ambiguous rules, users are directed to:
1. Local Gram Panchayat (rural schemes)
2. Urban Local Body (urban schemes)
3. Common Service Centre (CSC) for multi-scheme guidance
4. Scheme-specific helpline (listed in each scheme JSON)

---

**Document Version:** April 2026  
**Next Update:** When new schemes are added or existing rules change (quarterly recommended).
